import { useState, useEffect, useCallback } from "react";

const ADMIN_PASSWORD = "staples2024";
const STATUS = { UNKNOWN: "unknown", UP: "up", DOWN: "down", BUSY: "busy" };
const STATUS_CONFIG = {
  unknown: { label: "No Reports", color: "#94a3b8", bg: "#f1f5f9", border: "#e2e8f0", dot: "#cbd5e1" },
  up:      { label: "Working",    color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0", dot: "#22c55e" },
  down:    { label: "Down",       color: "#dc2626", bg: "#fff1f2", border: "#fecdd3", dot: "#ef4444" },
  busy:    { label: "Long Wait",  color: "#d97706", bg: "#fffbeb", border: "#fde68a", dot: "#f59e0b" },
};
const DOWN_OPTS = [
  { label:"15 min",  ms:15*60000 },{ label:"30 min",  ms:30*60000 },
  { label:"1 hour",  ms:3600000  },{ label:"2 hours", ms:7200000  },
  { label:"3 hours", ms:10800000 },{ label:"Half day",ms:21600000 },
  { label:"All day", ms:72000000 },{ label:"1 day",   ms:86400000 },
  { label:"2 days",  ms:172800000},{ label:"3 days",  ms:259200000},
  { label:"1 week",  ms:604800000},{ label:"Not sure",ms:14400000 },
];
const RESET_MS = { up:4*3600000, busy:30*60000, down:null, unknown:null };

// Large built-in ZIP → {lat,lng,city,state} table covering all major US metros
const ZIP_DB = {
  // New York
  "10001":{lat:40.7484,lng:-73.9967,city:"New York",state:"NY"},
  "10002":{lat:40.7157,lng:-73.9863,city:"New York",state:"NY"},
  "10003":{lat:40.7317,lng:-73.9892,city:"New York",state:"NY"},
  "10004":{lat:40.6998,lng:-74.0401,city:"New York",state:"NY"},
  "10005":{lat:40.7069,lng:-74.0089,city:"New York",state:"NY"},
  "10006":{lat:40.7085,lng:-74.0132,city:"New York",state:"NY"},
  "10007":{lat:40.7135,lng:-74.0078,city:"New York",state:"NY"},
  "10009":{lat:40.7263,lng:-73.9777,city:"New York",state:"NY"},
  "10010":{lat:40.7390,lng:-73.9833,city:"New York",state:"NY"},
  "10011":{lat:40.7423,lng:-74.0001,city:"New York",state:"NY"},
  "10012":{lat:40.7257,lng:-73.9981,city:"New York",state:"NY"},
  "10013":{lat:40.7197,lng:-74.0030,city:"New York",state:"NY"},
  "10014":{lat:40.7334,lng:-74.0045,city:"New York",state:"NY"},
  "10016":{lat:40.7459,lng:-73.9777,city:"New York",state:"NY"},
  "10017":{lat:40.7524,lng:-73.9736,city:"New York",state:"NY"},
  "10018":{lat:40.7556,lng:-73.9925,city:"New York",state:"NY"},
  "10019":{lat:40.7651,lng:-73.9870,city:"New York",state:"NY"},
  "10020":{lat:40.7589,lng:-73.9794,city:"New York",state:"NY"},
  "10021":{lat:40.7693,lng:-73.9574,city:"New York",state:"NY"},
  "10022":{lat:40.7580,lng:-73.9672,city:"New York",state:"NY"},
  "10023":{lat:40.7769,lng:-73.9822,city:"New York",state:"NY"},
  "10024":{lat:40.7870,lng:-73.9754,city:"New York",state:"NY"},
  "10025":{lat:40.7973,lng:-73.9684,city:"New York",state:"NY"},
  "10026":{lat:40.8025,lng:-73.9536,city:"New York",state:"NY"},
  "10027":{lat:40.8117,lng:-73.9530,city:"New York",state:"NY"},
  "10028":{lat:40.7770,lng:-73.9560,city:"New York",state:"NY"},
  "10029":{lat:40.7921,lng:-73.9448,city:"New York",state:"NY"},
  "10030":{lat:40.8188,lng:-73.9411,city:"New York",state:"NY"},
  "10031":{lat:40.8257,lng:-73.9497,city:"New York",state:"NY"},
  "10032":{lat:40.8380,lng:-73.9420,city:"New York",state:"NY"},
  "10033":{lat:40.8493,lng:-73.9338,city:"New York",state:"NY"},
  "10034":{lat:40.8677,lng:-73.9230,city:"New York",state:"NY"},
  "10035":{lat:40.7985,lng:-73.9333,city:"New York",state:"NY"},
  "10036":{lat:40.7601,lng:-73.9925,city:"New York",state:"NY"},
  "10037":{lat:40.8127,lng:-73.9373,city:"New York",state:"NY"},
  "10038":{lat:40.7075,lng:-74.0024,city:"New York",state:"NY"},
  "10039":{lat:40.8282,lng:-73.9373,city:"New York",state:"NY"},
  "10040":{lat:40.8589,lng:-73.9303,city:"New York",state:"NY"},
  // Brooklyn
  "11201":{lat:40.6928,lng:-73.9903,city:"Brooklyn",state:"NY"},
  "11203":{lat:40.6484,lng:-73.9385,city:"Brooklyn",state:"NY"},
  "11204":{lat:40.6196,lng:-73.9820,city:"Brooklyn",state:"NY"},
  "11205":{lat:40.6950,lng:-73.9669,city:"Brooklyn",state:"NY"},
  "11206":{lat:40.7032,lng:-73.9437,city:"Brooklyn",state:"NY"},
  "11207":{lat:40.6700,lng:-73.8918,city:"Brooklyn",state:"NY"},
  "11208":{lat:40.6726,lng:-73.8721,city:"Brooklyn",state:"NY"},
  "11209":{lat:40.6219,lng:-74.0300,city:"Brooklyn",state:"NY"},
  "11210":{lat:40.6335,lng:-73.9454,city:"Brooklyn",state:"NY"},
  "11211":{lat:40.7128,lng:-73.9538,city:"Brooklyn",state:"NY"},
  "11212":{lat:40.6613,lng:-73.9183,city:"Brooklyn",state:"NY"},
  "11213":{lat:40.6701,lng:-73.9347,city:"Brooklyn",state:"NY"},
  "11214":{lat:40.6005,lng:-73.9960,city:"Brooklyn",state:"NY"},
  "11215":{lat:40.6602,lng:-73.9829,city:"Brooklyn",state:"NY"},
  "11216":{lat:40.6793,lng:-73.9501,city:"Brooklyn",state:"NY"},
  "11217":{lat:40.6810,lng:-73.9776,city:"Brooklyn",state:"NY"},
  "11218":{lat:40.6437,lng:-73.9708,city:"Brooklyn",state:"NY"},
  "11219":{lat:40.6338,lng:-73.9980,city:"Brooklyn",state:"NY"},
  "11220":{lat:40.6402,lng:-74.0149,city:"Brooklyn",state:"NY"},
  "11221":{lat:40.6926,lng:-73.9258,city:"Brooklyn",state:"NY"},
  "11222":{lat:40.7244,lng:-73.9430,city:"Brooklyn",state:"NY"},
  "11223":{lat:40.5975,lng:-73.9700,city:"Brooklyn",state:"NY"},
  "11224":{lat:40.5754,lng:-73.9932,city:"Brooklyn",state:"NY"},
  "11225":{lat:40.6621,lng:-73.9535,city:"Brooklyn",state:"NY"},
  "11226":{lat:40.6448,lng:-73.9558,city:"Brooklyn",state:"NY"},
  "11228":{lat:40.6148,lng:-74.0157,city:"Brooklyn",state:"NY"},
  "11229":{lat:40.6017,lng:-73.9427,city:"Brooklyn",state:"NY"},
  "11230":{lat:40.6217,lng:-73.9608,city:"Brooklyn",state:"NY"},
  "11231":{lat:40.6754,lng:-74.0001,city:"Brooklyn",state:"NY"},
  "11232":{lat:40.6558,lng:-74.0005,city:"Brooklyn",state:"NY"},
  "11233":{lat:40.6795,lng:-73.9153,city:"Brooklyn",state:"NY"},
  "11234":{lat:40.6153,lng:-73.9130,city:"Brooklyn",state:"NY"},
  "11235":{lat:40.5833,lng:-73.9445,city:"Brooklyn",state:"NY"},
  "11236":{lat:40.6338,lng:-73.9018,city:"Brooklyn",state:"NY"},
  "11237":{lat:40.7052,lng:-73.9175,city:"Brooklyn",state:"NY"},
  "11238":{lat:40.6793,lng:-73.9647,city:"Brooklyn",state:"NY"},
  // Queens
  "11354":{lat:40.7677,lng:-73.8298,city:"Flushing",state:"NY"},
  "11355":{lat:40.7489,lng:-73.8219,city:"Flushing",state:"NY"},
  "11368":{lat:40.7468,lng:-73.8637,city:"Corona",state:"NY"},
  "11373":{lat:40.7372,lng:-73.8782,city:"Elmhurst",state:"NY"},
  "11375":{lat:40.7215,lng:-73.8487,city:"Forest Hills",state:"NY"},
  "11377":{lat:40.7446,lng:-73.9061,city:"Woodside",state:"NY"},
  "11385":{lat:40.7027,lng:-73.8841,city:"Ridgewood",state:"NY"},
  // Los Angeles
  "90001":{lat:33.9731,lng:-118.2479,city:"Los Angeles",state:"CA"},
  "90002":{lat:33.9490,lng:-118.2467,city:"Los Angeles",state:"CA"},
  "90003":{lat:33.9639,lng:-118.2731,city:"Los Angeles",state:"CA"},
  "90004":{lat:34.0762,lng:-118.3089,city:"Los Angeles",state:"CA"},
  "90005":{lat:34.0592,lng:-118.3024,city:"Los Angeles",state:"CA"},
  "90006":{lat:34.0480,lng:-118.2921,city:"Los Angeles",state:"CA"},
  "90007":{lat:34.0269,lng:-118.2804,city:"Los Angeles",state:"CA"},
  "90008":{lat:34.0048,lng:-118.3508,city:"Los Angeles",state:"CA"},
  "90010":{lat:34.0633,lng:-118.3150,city:"Los Angeles",state:"CA"},
  "90011":{lat:34.0059,lng:-118.2715,city:"Los Angeles",state:"CA"},
  "90012":{lat:34.0658,lng:-118.2381,city:"Los Angeles",state:"CA"},
  "90013":{lat:34.0424,lng:-118.2430,city:"Los Angeles",state:"CA"},
  "90014":{lat:34.0430,lng:-118.2568,city:"Los Angeles",state:"CA"},
  "90015":{lat:34.0371,lng:-118.2691,city:"Los Angeles",state:"CA"},
  "90016":{lat:34.0199,lng:-118.3497,city:"Los Angeles",state:"CA"},
  "90017":{lat:34.0539,lng:-118.2697,city:"Los Angeles",state:"CA"},
  "90018":{lat:34.0189,lng:-118.3191,city:"Los Angeles",state:"CA"},
  "90019":{lat:34.0440,lng:-118.3412,city:"Los Angeles",state:"CA"},
  "90020":{lat:34.0710,lng:-118.3074,city:"Los Angeles",state:"CA"},
  "90021":{lat:34.0299,lng:-118.2441,city:"Los Angeles",state:"CA"},
  "90022":{lat:34.0235,lng:-118.1508,city:"Los Angeles",state:"CA"},
  "90023":{lat:34.0253,lng:-118.2056,city:"Los Angeles",state:"CA"},
  "90024":{lat:34.0634,lng:-118.4461,city:"Los Angeles",state:"CA"},
  "90025":{lat:34.0481,lng:-118.4547,city:"Los Angeles",state:"CA"},
  "90026":{lat:34.0780,lng:-118.2608,city:"Los Angeles",state:"CA"},
  "90027":{lat:34.1063,lng:-118.2901,city:"Los Angeles",state:"CA"},
  "90028":{lat:34.1002,lng:-118.3282,city:"Los Angeles",state:"CA"},
  "90029":{lat:34.0893,lng:-118.2992,city:"Los Angeles",state:"CA"},
  "90031":{lat:34.0799,lng:-118.2143,city:"Los Angeles",state:"CA"},
  "90032":{lat:34.0799,lng:-118.1813,city:"Los Angeles",state:"CA"},
  "90033":{lat:34.0510,lng:-118.2105,city:"Los Angeles",state:"CA"},
  "90034":{lat:34.0268,lng:-118.3966,city:"Los Angeles",state:"CA"},
  "90035":{lat:34.0528,lng:-118.3760,city:"Los Angeles",state:"CA"},
  "90036":{lat:34.0693,lng:-118.3519,city:"Los Angeles",state:"CA"},
  "90037":{lat:34.0007,lng:-118.2895,city:"Los Angeles",state:"CA"},
  "90038":{lat:34.0900,lng:-118.3379,city:"Los Angeles",state:"CA"},
  "90039":{lat:34.1076,lng:-118.2608,city:"Los Angeles",state:"CA"},
  "90041":{lat:34.1374,lng:-118.2059,city:"Los Angeles",state:"CA"},
  "90042":{lat:34.1182,lng:-118.1940,city:"Los Angeles",state:"CA"},
  "90043":{lat:33.9836,lng:-118.3303,city:"Los Angeles",state:"CA"},
  "90044":{lat:33.9556,lng:-118.2989,city:"Los Angeles",state:"CA"},
  "90045":{lat:33.9600,lng:-118.3988,city:"Los Angeles",state:"CA"},
  "90046":{lat:34.1012,lng:-118.3631,city:"Los Angeles",state:"CA"},
  "90047":{lat:33.9590,lng:-118.3090,city:"Los Angeles",state:"CA"},
  "90048":{lat:34.0760,lng:-118.3738,city:"Los Angeles",state:"CA"},
  "90049":{lat:34.0669,lng:-118.4799,city:"Los Angeles",state:"CA"},
  "90056":{lat:33.9908,lng:-118.3718,city:"Los Angeles",state:"CA"},
  "90057":{lat:34.0611,lng:-118.2817,city:"Los Angeles",state:"CA"},
  "90058":{lat:33.9966,lng:-118.2142,city:"Los Angeles",state:"CA"},
  "90059":{lat:33.9339,lng:-118.2444,city:"Los Angeles",state:"CA"},
  "90061":{lat:33.9239,lng:-118.2729,city:"Los Angeles",state:"CA"},
  "90062":{lat:34.0002,lng:-118.3090,city:"Los Angeles",state:"CA"},
  "90063":{lat:34.0410,lng:-118.1849,city:"Los Angeles",state:"CA"},
  "90064":{lat:34.0323,lng:-118.4265,city:"Los Angeles",state:"CA"},
  "90065":{lat:34.1025,lng:-118.2295,city:"Los Angeles",state:"CA"},
  "90066":{lat:34.0003,lng:-118.4291,city:"Los Angeles",state:"CA"},
  "90067":{lat:34.0560,lng:-118.4149,city:"Los Angeles",state:"CA"},
  "90068":{lat:34.1197,lng:-118.3379,city:"Los Angeles",state:"CA"},
  "90069":{lat:34.0907,lng:-118.3800,city:"Los Angeles",state:"CA"},
  "90071":{lat:34.0526,lng:-118.2540,city:"Los Angeles",state:"CA"},
  "90073":{lat:34.0458,lng:-118.4596,city:"Los Angeles",state:"CA"},
  "90077":{lat:34.0944,lng:-118.4644,city:"Los Angeles",state:"CA"},
  "90210":{lat:34.0901,lng:-118.4065,city:"Beverly Hills",state:"CA"},
  "90211":{lat:34.0788,lng:-118.3888,city:"Beverly Hills",state:"CA"},
  "90212":{lat:34.0684,lng:-118.3956,city:"Beverly Hills",state:"CA"},
  "90230":{lat:33.9981,lng:-118.3962,city:"Culver City",state:"CA"},
  "90232":{lat:34.0219,lng:-118.3921,city:"Culver City",state:"CA"},
  "90247":{lat:33.8879,lng:-118.2958,city:"Gardena",state:"CA"},
  "90248":{lat:33.8698,lng:-118.2760,city:"Gardena",state:"CA"},
  "90272":{lat:34.0467,lng:-118.5320,city:"Pacific Palisades",state:"CA"},
  "90291":{lat:33.9973,lng:-118.4650,city:"Venice",state:"CA"},
  "90292":{lat:33.9842,lng:-118.4477,city:"Marina del Rey",state:"CA"},
  "90401":{lat:34.0159,lng:-118.4938,city:"Santa Monica",state:"CA"},
  "90402":{lat:34.0349,lng:-118.5007,city:"Santa Monica",state:"CA"},
  "90403":{lat:34.0280,lng:-118.4945,city:"Santa Monica",state:"CA"},
  "90404":{lat:34.0245,lng:-118.4749,city:"Santa Monica",state:"CA"},
  "90405":{lat:34.0087,lng:-118.4749,city:"Santa Monica",state:"CA"},
  "91401":{lat:34.1843,lng:-118.4012,city:"Van Nuys",state:"CA"},
  "91402":{lat:34.2097,lng:-118.4148,city:"Panorama City",state:"CA"},
  "91403":{lat:34.1545,lng:-118.4622,city:"Sherman Oaks",state:"CA"},
  "91411":{lat:34.0019,lng:-118.4491,city:"Van Nuys",state:"CA"},
  "91423":{lat:34.1517,lng:-118.4281,city:"Sherman Oaks",state:"CA"},
  "91601":{lat:34.1654,lng:-118.3732,city:"North Hollywood",state:"CA"},
  "91602":{lat:34.1567,lng:-118.3621,city:"North Hollywood",state:"CA"},
  "91604":{lat:34.1458,lng:-118.3683,city:"Studio City",state:"CA"},
  "91606":{lat:34.1879,lng:-118.3969,city:"North Hollywood",state:"CA"},
  // Chicago
  "60601":{lat:41.8858,lng:-87.6181,city:"Chicago",state:"IL"},
  "60602":{lat:41.8827,lng:-87.6296,city:"Chicago",state:"IL"},
  "60603":{lat:41.8797,lng:-87.6299,city:"Chicago",state:"IL"},
  "60604":{lat:41.8767,lng:-87.6334,city:"Chicago",state:"IL"},
  "60605":{lat:41.8659,lng:-87.6215,city:"Chicago",state:"IL"},
  "60606":{lat:41.8832,lng:-87.6407,city:"Chicago",state:"IL"},
  "60607":{lat:41.8724,lng:-87.6630,city:"Chicago",state:"IL"},
  "60608":{lat:41.8489,lng:-87.6642,city:"Chicago",state:"IL"},
  "60609":{lat:41.8200,lng:-87.6473,city:"Chicago",state:"IL"},
  "60610":{lat:41.9028,lng:-87.6311,city:"Chicago",state:"IL"},
  "60611":{lat:41.8962,lng:-87.6212,city:"Chicago",state:"IL"},
  "60612":{lat:41.8783,lng:-87.6942,city:"Chicago",state:"IL"},
  "60613":{lat:41.9558,lng:-87.6565,city:"Chicago",state:"IL"},
  "60614":{lat:41.9216,lng:-87.6459,city:"Chicago",state:"IL"},
  "60615":{lat:41.7988,lng:-87.5992,city:"Chicago",state:"IL"},
  "60616":{lat:41.8443,lng:-87.6288,city:"Chicago",state:"IL"},
  "60617":{lat:41.7193,lng:-87.5560,city:"Chicago",state:"IL"},
  "60618":{lat:41.9456,lng:-87.6975,city:"Chicago",state:"IL"},
  "60619":{lat:41.7453,lng:-87.6003,city:"Chicago",state:"IL"},
  "60620":{lat:41.7478,lng:-87.6497,city:"Chicago",state:"IL"},
  "60621":{lat:41.7769,lng:-87.6406,city:"Chicago",state:"IL"},
  "60622":{lat:41.9027,lng:-87.6776,city:"Chicago",state:"IL"},
  "60623":{lat:41.8481,lng:-87.7148,city:"Chicago",state:"IL"},
  "60624":{lat:41.8800,lng:-87.7248,city:"Chicago",state:"IL"},
  "60625":{lat:41.9714,lng:-87.7005,city:"Chicago",state:"IL"},
  "60626":{lat:42.0038,lng:-87.6662,city:"Chicago",state:"IL"},
  "60628":{lat:41.6962,lng:-87.6156,city:"Chicago",state:"IL"},
  "60629":{lat:41.7764,lng:-87.7039,city:"Chicago",state:"IL"},
  "60630":{lat:41.9864,lng:-87.7520,city:"Chicago",state:"IL"},
  "60631":{lat:41.9989,lng:-87.8150,city:"Chicago",state:"IL"},
  "60632":{lat:41.8114,lng:-87.7248,city:"Chicago",state:"IL"},
  "60634":{lat:41.9447,lng:-87.7905,city:"Chicago",state:"IL"},
  "60636":{lat:41.7764,lng:-87.6640,city:"Chicago",state:"IL"},
  "60637":{lat:41.7816,lng:-87.5989,city:"Chicago",state:"IL"},
  "60638":{lat:41.7853,lng:-87.7614,city:"Chicago",state:"IL"},
  "60639":{lat:41.9213,lng:-87.7576,city:"Chicago",state:"IL"},
  "60640":{lat:41.9719,lng:-87.6575,city:"Chicago",state:"IL"},
  "60641":{lat:41.9458,lng:-87.7530,city:"Chicago",state:"IL"},
  "60642":{lat:41.8990,lng:-87.6614,city:"Chicago",state:"IL"},
  "60643":{lat:41.6987,lng:-87.6570,city:"Chicago",state:"IL"},
  "60644":{lat:41.8814,lng:-87.7487,city:"Chicago",state:"IL"},
  "60645":{lat:42.0100,lng:-87.6975,city:"Chicago",state:"IL"},
  "60646":{lat:41.9978,lng:-87.7568,city:"Chicago",state:"IL"},
  "60647":{lat:41.9298,lng:-87.6879,city:"Chicago",state:"IL"},
  "60649":{lat:41.7618,lng:-87.5643,city:"Chicago",state:"IL"},
  "60651":{lat:41.8983,lng:-87.7258,city:"Chicago",state:"IL"},
  "60652":{lat:41.7474,lng:-87.7144,city:"Chicago",state:"IL"},
  "60653":{lat:41.8183,lng:-87.6080,city:"Chicago",state:"IL"},
  "60654":{lat:41.8930,lng:-87.6358,city:"Chicago",state:"IL"},
  "60657":{lat:41.9401,lng:-87.6513,city:"Chicago",state:"IL"},
  "60660":{lat:41.9886,lng:-87.6598,city:"Chicago",state:"IL"},
  // Houston
  "77001":{lat:29.7543,lng:-95.3677,city:"Houston",state:"TX"},
  "77002":{lat:29.7555,lng:-95.3677,city:"Houston",state:"TX"},
  "77003":{lat:29.7413,lng:-95.3481,city:"Houston",state:"TX"},
  "77004":{lat:29.7231,lng:-95.3677,city:"Houston",state:"TX"},
  "77005":{lat:29.7172,lng:-95.4241,city:"Houston",state:"TX"},
  "77006":{lat:29.7413,lng:-95.3913,city:"Houston",state:"TX"},
  "77007":{lat:29.7676,lng:-95.4020,city:"Houston",state:"TX"},
  "77008":{lat:29.7898,lng:-95.4149,city:"Houston",state:"TX"},
  "77009":{lat:29.7898,lng:-95.3677,city:"Houston",state:"TX"},
  "77010":{lat:29.7544,lng:-95.3620,city:"Houston",state:"TX"},
  "77011":{lat:29.7231,lng:-95.3177,city:"Houston",state:"TX"},
  "77012":{lat:29.7059,lng:-95.2899,city:"Houston",state:"TX"},
  "77013":{lat:29.7231,lng:-95.2371,city:"Houston",state:"TX"},
  "77014":{lat:29.9572,lng:-95.4785,city:"Houston",state:"TX"},
  "77015":{lat:29.7059,lng:-95.1849,city:"Houston",state:"TX"},
  "77016":{lat:29.8276,lng:-95.3285,city:"Houston",state:"TX"},
  "77017":{lat:29.6831,lng:-95.2727,city:"Houston",state:"TX"},
  "77018":{lat:29.8276,lng:-95.4106,city:"Houston",state:"TX"},
  "77019":{lat:29.7511,lng:-95.4203,city:"Houston",state:"TX"},
  "77020":{lat:29.7676,lng:-95.3113,city:"Houston",state:"TX"},
  "77021":{lat:29.6831,lng:-95.3677,city:"Houston",state:"TX"},
  "77022":{lat:29.8108,lng:-95.3742,city:"Houston",state:"TX"},
  "77023":{lat:29.7059,lng:-95.3306,city:"Houston",state:"TX"},
  "77024":{lat:29.7734,lng:-95.5192,city:"Houston",state:"TX"},
  "77025":{lat:29.6831,lng:-95.4306,city:"Houston",state:"TX"},
  "77026":{lat:29.7898,lng:-95.3285,city:"Houston",state:"TX"},
  "77027":{lat:29.7415,lng:-95.4570,city:"Houston",state:"TX"},
  "77028":{lat:29.8108,lng:-95.2963,city:"Houston",state:"TX"},
  "77030":{lat:29.7059,lng:-95.3984,city:"Houston",state:"TX"},
  "77031":{lat:29.6546,lng:-95.5449,city:"Houston",state:"TX"},
  "77033":{lat:29.6659,lng:-95.3306,city:"Houston",state:"TX"},
  "77035":{lat:29.6546,lng:-95.4656,city:"Houston",state:"TX"},
  "77036":{lat:29.6946,lng:-95.5385,city:"Houston",state:"TX"},
  "77040":{lat:29.8833,lng:-95.5192,city:"Houston",state:"TX"},
  "77041":{lat:29.8551,lng:-95.5621,city:"Houston",state:"TX"},
  "77042":{lat:29.7344,lng:-95.5621,city:"Houston",state:"TX"},
  "77043":{lat:29.7898,lng:-95.5492,city:"Houston",state:"TX"},
  "77045":{lat:29.6274,lng:-95.4399,city:"Houston",state:"TX"},
  "77046":{lat:29.7402,lng:-95.4634,city:"Houston",state:"TX"},
  "77047":{lat:29.6274,lng:-95.3720,city:"Houston",state:"TX"},
  "77048":{lat:29.6274,lng:-95.3027,city:"Houston",state:"TX"},
  "77051":{lat:29.6488,lng:-95.3977,city:"Houston",state:"TX"},
  "77054":{lat:29.6946,lng:-95.4149,city:"Houston",state:"TX"},
  "77055":{lat:29.7898,lng:-95.4785,city:"Houston",state:"TX"},
  "77056":{lat:29.7512,lng:-95.4806,city:"Houston",state:"TX"},
  "77057":{lat:29.7502,lng:-95.5063,city:"Houston",state:"TX"},
  "77058":{lat:29.5619,lng:-95.1085,city:"Houston",state:"TX"},
  "77059":{lat:29.5802,lng:-95.1442,city:"Houston",state:"TX"},
  "77060":{lat:29.9094,lng:-95.3720,city:"Houston",state:"TX"},
  "77061":{lat:29.6659,lng:-95.2520,city:"Houston",state:"TX"},
  "77062":{lat:29.5947,lng:-95.1499,city:"Houston",state:"TX"},
  "77063":{lat:29.7370,lng:-95.5013,city:"Houston",state:"TX"},
  "77064":{lat:29.9241,lng:-95.5492,city:"Houston",state:"TX"},
  "77065":{lat:29.9094,lng:-95.6085,city:"Houston",state:"TX"},
  "77066":{lat:29.9572,lng:-95.4999,city:"Houston",state:"TX"},
  "77067":{lat:29.9572,lng:-95.4399,city:"Houston",state:"TX"},
  "77068":{lat:29.9900,lng:-95.5085,city:"Houston",state:"TX"},
  "77069":{lat:29.9900,lng:-95.5492,city:"Houston",state:"TX"},
  "77070":{lat:29.9572,lng:-95.6085,city:"Houston",state:"TX"},
  "77071":{lat:29.6659,lng:-95.4913,city:"Houston",state:"TX"},
  "77072":{lat:29.7059,lng:-95.5749,city:"Houston",state:"TX"},
  "77073":{lat:29.9900,lng:-95.3827,city:"Houston",state:"TX"},
  "77074":{lat:29.6831,lng:-95.5049,city:"Houston",state:"TX"},
  "77075":{lat:29.6274,lng:-95.2749,city:"Houston",state:"TX"},
  "77076":{lat:29.8551,lng:-95.3827,city:"Houston",state:"TX"},
  "77077":{lat:29.7512,lng:-95.6185,city:"Houston",state:"TX"},
  "77078":{lat:29.7898,lng:-95.2413,city:"Houston",state:"TX"},
  "77079":{lat:29.7676,lng:-95.5749,city:"Houston",state:"TX"},
  "77080":{lat:29.8276,lng:-95.4785,city:"Houston",state:"TX"},
  "77081":{lat:29.7059,lng:-95.4656,city:"Houston",state:"TX"},
  "77082":{lat:29.7231,lng:-95.6021,city:"Houston",state:"TX"},
  "77083":{lat:29.6946,lng:-95.6399,city:"Houston",state:"TX"},
  "77084":{lat:29.8276,lng:-95.6621,city:"Houston",state:"TX"},
  "77085":{lat:29.6274,lng:-95.4613,city:"Houston",state:"TX"},
  "77086":{lat:29.9241,lng:-95.4492,city:"Houston",state:"TX"},
  "77087":{lat:29.6831,lng:-95.2920,city:"Houston",state:"TX"},
  "77088":{lat:29.8833,lng:-95.4485,city:"Houston",state:"TX"},
  "77089":{lat:29.5947,lng:-95.2413,city:"Houston",state:"TX"},
  "77090":{lat:30.0047,lng:-95.4185,city:"Houston",state:"TX"},
  "77091":{lat:29.8551,lng:-95.4249,city:"Houston",state:"TX"},
  "77092":{lat:29.8276,lng:-95.4399,city:"Houston",state:"TX"},
  "77093":{lat:29.8551,lng:-95.3349,city:"Houston",state:"TX"},
  "77094":{lat:29.7676,lng:-95.6621,city:"Houston",state:"TX"},
  "77095":{lat:29.8551,lng:-95.6385,city:"Houston",state:"TX"},
  "77096":{lat:29.6659,lng:-95.4613,city:"Houston",state:"TX"},
  "77098":{lat:29.7344,lng:-95.4149,city:"Houston",state:"TX"},
  "77099":{lat:29.6946,lng:-95.5992,city:"Houston",state:"TX"},
  // Miami
  "33101":{lat:25.7617,lng:-80.1918,city:"Miami",state:"FL"},
  "33125":{lat:25.7739,lng:-80.2284,city:"Miami",state:"FL"},
  "33126":{lat:25.7674,lng:-80.2838,city:"Miami",state:"FL"},
  "33127":{lat:25.8103,lng:-80.2020,city:"Miami",state:"FL"},
  "33128":{lat:25.7770,lng:-80.1990,city:"Miami",state:"FL"},
  "33129":{lat:25.7459,lng:-80.2020,city:"Miami",state:"FL"},
  "33130":{lat:25.7632,lng:-80.1961,city:"Miami",state:"FL"},
  "33131":{lat:25.7617,lng:-80.1867,city:"Miami",state:"FL"},
  "33132":{lat:25.7775,lng:-80.1775,city:"Miami",state:"FL"},
  "33133":{lat:25.7290,lng:-80.2373,city:"Miami",state:"FL"},
  "33134":{lat:25.7530,lng:-80.2624,city:"Miami",state:"FL"},
  "33135":{lat:25.7675,lng:-80.2416,city:"Miami",state:"FL"},
  "33136":{lat:25.7877,lng:-80.2043,city:"Miami",state:"FL"},
  "33137":{lat:25.8117,lng:-80.1810,city:"Miami",state:"FL"},
  "33138":{lat:25.8489,lng:-80.1718,city:"Miami",state:"FL"},
  "33139":{lat:25.7775,lng:-80.1318,city:"Miami",state:"FL"},
  "33140":{lat:25.8021,lng:-80.1318,city:"Miami",state:"FL"},
  "33141":{lat:25.8345,lng:-80.1318,city:"Miami",state:"FL"},
  "33142":{lat:25.8117,lng:-80.2416,city:"Miami",state:"FL"},
  "33143":{lat:25.7006,lng:-80.2838,city:"Miami",state:"FL"},
  "33144":{lat:25.7530,lng:-80.3173,city:"Miami",state:"FL"},
  "33145":{lat:25.7530,lng:-80.2330,city:"Miami",state:"FL"},
  "33146":{lat:25.7149,lng:-80.2752,city:"Miami",state:"FL"},
  "33147":{lat:25.8436,lng:-80.2316,city:"Miami",state:"FL"},
  "33150":{lat:25.8632,lng:-80.2130,city:"Miami",state:"FL"},
  "33155":{lat:25.7326,lng:-80.3161,city:"Miami",state:"FL"},
  "33156":{lat:25.6776,lng:-80.3173,city:"Miami",state:"FL"},
  "33157":{lat:25.6218,lng:-80.3730,city:"Miami",state:"FL"},
  "33160":{lat:25.9292,lng:-80.1318,city:"North Miami Beach",state:"FL"},
  "33161":{lat:25.8917,lng:-80.1810,city:"North Miami",state:"FL"},
  "33162":{lat:25.9292,lng:-80.1810,city:"North Miami Beach",state:"FL"},
  "33165":{lat:25.7344,lng:-80.3559,city:"Miami",state:"FL"},
  "33166":{lat:25.8117,lng:-80.3259,city:"Miami",state:"FL"},
  "33167":{lat:25.8702,lng:-80.2459,city:"Miami",state:"FL"},
  "33168":{lat:25.8917,lng:-80.2130,city:"Miami",state:"FL"},
  "33169":{lat:25.9401,lng:-80.2130,city:"Miami",state:"FL"},
  "33170":{lat:25.5619,lng:-80.4173,city:"Miami",state:"FL"},
  "33172":{lat:25.7649,lng:-80.3923,city:"Miami",state:"FL"},
  "33174":{lat:25.7530,lng:-80.3623,city:"Miami",state:"FL"},
  "33175":{lat:25.7306,lng:-80.3923,city:"Miami",state:"FL"},
  "33176":{lat:25.6776,lng:-80.3559,city:"Miami",state:"FL"},
  "33177":{lat:25.6218,lng:-80.4173,city:"Miami",state:"FL"},
  "33178":{lat:25.8117,lng:-80.4316,city:"Miami",state:"FL"},
  "33179":{lat:25.9615,lng:-80.1961,city:"Miami",state:"FL"},
  "33180":{lat:25.9615,lng:-80.1461,city:"Aventura",state:"FL"},
  "33181":{lat:25.8917,lng:-80.1461,city:"North Miami Beach",state:"FL"},
  "33183":{lat:25.7006,lng:-80.3923,city:"Miami",state:"FL"},
  "33184":{lat:25.7344,lng:-80.4173,city:"Miami",state:"FL"},
  "33185":{lat:25.7149,lng:-80.4316,city:"Miami",state:"FL"},
  "33186":{lat:25.6618,lng:-80.4173,city:"Miami",state:"FL"},
  "33187":{lat:25.6218,lng:-80.4730,city:"Miami",state:"FL"},
  "33189":{lat:25.5802,lng:-80.4316,city:"Miami",state:"FL"},
  "33193":{lat:25.6948,lng:-80.4559,city:"Miami",state:"FL"},
  "33194":{lat:25.7344,lng:-80.4816,city:"Miami",state:"FL"},
  "33196":{lat:25.6618,lng:-80.4730,city:"Miami",state:"FL"},
  // Boston
  "02101":{lat:42.3601,lng:-71.0589,city:"Boston",state:"MA"},
  "02108":{lat:42.3573,lng:-71.0632,city:"Boston",state:"MA"},
  "02109":{lat:42.3662,lng:-71.0528,city:"Boston",state:"MA"},
  "02110":{lat:42.3549,lng:-71.0575,city:"Boston",state:"MA"},
  "02111":{lat:42.3500,lng:-71.0618,city:"Boston",state:"MA"},
  "02112":{lat:42.3399,lng:-71.0887,city:"Boston",state:"MA"},
  "02113":{lat:42.3662,lng:-71.0564,city:"Boston",state:"MA"},
  "02114":{lat:42.3614,lng:-71.0695,city:"Boston",state:"MA"},
  "02115":{lat:42.3442,lng:-71.0938,city:"Boston",state:"MA"},
  "02116":{lat:42.3488,lng:-71.0757,city:"Boston",state:"MA"},
  "02117":{lat:42.3470,lng:-71.0838,city:"Boston",state:"MA"},
  "02118":{lat:42.3385,lng:-71.0696,city:"Boston",state:"MA"},
  "02119":{lat:42.3241,lng:-71.0853,city:"Boston",state:"MA"},
  "02120":{lat:42.3299,lng:-71.0990,city:"Boston",state:"MA"},
  "02121":{lat:42.3082,lng:-71.0790,city:"Boston",state:"MA"},
  "02122":{lat:42.2970,lng:-71.0513,city:"Boston",state:"MA"},
  "02124":{lat:42.2889,lng:-71.0694,city:"Boston",state:"MA"},
  "02125":{lat:42.3136,lng:-71.0566,city:"Boston",state:"MA"},
  "02126":{lat:42.2763,lng:-71.0929,city:"Boston",state:"MA"},
  "02127":{lat:42.3363,lng:-71.0327,city:"Boston",state:"MA"},
  "02128":{lat:42.3738,lng:-71.0190,city:"Boston",state:"MA"},
  "02129":{lat:42.3788,lng:-71.0598,city:"Boston",state:"MA"},
  "02130":{lat:42.3103,lng:-71.1142,city:"Boston",state:"MA"},
  "02131":{lat:42.2842,lng:-71.1140,city:"Boston",state:"MA"},
  "02132":{lat:42.2763,lng:-71.1579,city:"Boston",state:"MA"},
  "02134":{lat:42.3559,lng:-71.1340,city:"Boston",state:"MA"},
  "02135":{lat:42.3494,lng:-71.1571,city:"Brighton",state:"MA"},
  "02136":{lat:42.2551,lng:-71.1290,city:"Boston",state:"MA"},
  "02138":{lat:42.3793,lng:-71.1222,city:"Cambridge",state:"MA"},
  "02139":{lat:42.3651,lng:-71.1054,city:"Cambridge",state:"MA"},
  "02140":{lat:42.3938,lng:-71.1264,city:"Cambridge",state:"MA"},
  "02141":{lat:42.3671,lng:-71.0840,city:"Cambridge",state:"MA"},
  "02142":{lat:42.3621,lng:-71.0840,city:"Cambridge",state:"MA"},
  "02143":{lat:42.3821,lng:-71.0990,city:"Somerville",state:"MA"},
  "02144":{lat:42.3984,lng:-71.1222,city:"Somerville",state:"MA"},
  "02145":{lat:42.3882,lng:-71.0840,city:"Somerville",state:"MA"},
  // Seattle
  "98101":{lat:47.6062,lng:-122.3321,city:"Seattle",state:"WA"},
  "98102":{lat:47.6285,lng:-122.3225,city:"Seattle",state:"WA"},
  "98103":{lat:47.6866,lng:-122.3453,city:"Seattle",state:"WA"},
  "98104":{lat:47.6013,lng:-122.3302,city:"Seattle",state:"WA"},
  "98105":{lat:47.6598,lng:-122.2993,city:"Seattle",state:"WA"},
  "98106":{lat:47.5494,lng:-122.3569,city:"Seattle",state:"WA"},
  "98107":{lat:47.6699,lng:-122.3727,city:"Seattle",state:"WA"},
  "98108":{lat:47.5380,lng:-122.3070,city:"Seattle",state:"WA"},
  "98109":{lat:47.6366,lng:-122.3497,city:"Seattle",state:"WA"},
  "98110":{lat:47.6235,lng:-122.5227,city:"Bainbridge Island",state:"WA"},
  "98112":{lat:47.6352,lng:-122.2993,city:"Seattle",state:"WA"},
  "98115":{lat:47.6826,lng:-122.2993,city:"Seattle",state:"WA"},
  "98116":{lat:47.5644,lng:-122.3936,city:"Seattle",state:"WA"},
  "98117":{lat:47.6895,lng:-122.3782,city:"Seattle",state:"WA"},
  "98118":{lat:47.5494,lng:-122.2671,city:"Seattle",state:"WA"},
  "98119":{lat:47.6421,lng:-122.3700,city:"Seattle",state:"WA"},
  "98121":{lat:47.6145,lng:-122.3470,city:"Seattle",state:"WA"},
  "98122":{lat:47.6108,lng:-122.2993,city:"Seattle",state:"WA"},
  "98125":{lat:47.7213,lng:-122.3021,city:"Seattle",state:"WA"},
  "98126":{lat:47.5644,lng:-122.3700,city:"Seattle",state:"WA"},
  "98133":{lat:47.7009,lng:-122.3450,city:"Seattle",state:"WA"},
  "98134":{lat:47.5838,lng:-122.3302,city:"Seattle",state:"WA"},
  "98136":{lat:47.5380,lng:-122.3840,city:"Seattle",state:"WA"},
  "98144":{lat:47.5978,lng:-122.2912,city:"Seattle",state:"WA"},
  "98146":{lat:47.4972,lng:-122.3569,city:"Burien",state:"WA"},
  "98155":{lat:47.7494,lng:-122.3021,city:"Shoreline",state:"WA"},
  "98177":{lat:47.7699,lng:-122.3782,city:"Seattle",state:"WA"},
  "98178":{lat:47.4972,lng:-122.2389,city:"Seattle",state:"WA"},
  "98195":{lat:47.6553,lng:-122.3035,city:"Seattle",state:"WA"},
  "98199":{lat:47.6476,lng:-122.4009,city:"Seattle",state:"WA"},
  // Atlanta
  "30301":{lat:33.7490,lng:-84.3880,city:"Atlanta",state:"GA"},
  "30303":{lat:33.7531,lng:-84.3896,city:"Atlanta",state:"GA"},
  "30305":{lat:33.8349,lng:-84.3760,city:"Atlanta",state:"GA"},
  "30306":{lat:33.7853,lng:-84.3469,city:"Atlanta",state:"GA"},
  "30307":{lat:33.7712,lng:-84.3280,city:"Atlanta",state:"GA"},
  "30308":{lat:33.7712,lng:-84.3716,city:"Atlanta",state:"GA"},
  "30309":{lat:33.7898,lng:-84.3834,city:"Atlanta",state:"GA"},
  "30310":{lat:33.7244,lng:-84.4230,city:"Atlanta",state:"GA"},
  "30311":{lat:33.7303,lng:-84.4626,city:"Atlanta",state:"GA"},
  "30312":{lat:33.7412,lng:-84.3716,city:"Atlanta",state:"GA"},
  "30313":{lat:33.7531,lng:-84.3979,city:"Atlanta",state:"GA"},
  "30314":{lat:33.7530,lng:-84.4408,city:"Atlanta",state:"GA"},
  "30315":{lat:33.7126,lng:-84.3769,city:"Atlanta",state:"GA"},
  "30316":{lat:33.7200,lng:-84.3280,city:"Atlanta",state:"GA"},
  "30317":{lat:33.7503,lng:-84.3108,city:"Atlanta",state:"GA"},
  "30318":{lat:33.7853,lng:-84.4230,city:"Atlanta",state:"GA"},
  "30319":{lat:33.8651,lng:-84.3280,city:"Atlanta",state:"GA"},
  "30322":{lat:33.7937,lng:-84.3228,city:"Atlanta",state:"GA"},
  "30324":{lat:33.8435,lng:-84.3645,city:"Atlanta",state:"GA"},
  "30326":{lat:33.8481,lng:-84.3617,city:"Atlanta",state:"GA"},
  "30327":{lat:33.8710,lng:-84.4230,city:"Atlanta",state:"GA"},
  "30328":{lat:33.9303,lng:-84.3824,city:"Atlanta",state:"GA"},
  "30329":{lat:33.8200,lng:-84.3108,city:"Atlanta",state:"GA"},
  "30331":{lat:33.7126,lng:-84.5230,city:"Atlanta",state:"GA"},
  "30332":{lat:33.7756,lng:-84.3963,city:"Atlanta",state:"GA"},
  "30334":{lat:33.7490,lng:-84.3910,city:"Atlanta",state:"GA"},
  "30336":{lat:33.7303,lng:-84.5230,city:"Atlanta",state:"GA"},
  "30337":{lat:33.6503,lng:-84.4430,city:"Atlanta",state:"GA"},
  "30338":{lat:33.9503,lng:-84.3428,city:"Atlanta",state:"GA"},
  "30339":{lat:33.8710,lng:-84.4697,city:"Atlanta",state:"GA"},
  "30340":{lat:33.8885,lng:-84.2715,city:"Atlanta",state:"GA"},
  "30341":{lat:33.8885,lng:-84.2908,city:"Atlanta",state:"GA"},
  "30342":{lat:33.8710,lng:-84.3765,city:"Atlanta",state:"GA"},
  "30345":{lat:33.8385,lng:-84.2715,city:"Atlanta",state:"GA"},
  "30346":{lat:33.9185,lng:-84.3428,city:"Atlanta",state:"GA"},
  "30349":{lat:33.6185,lng:-84.4847,city:"Atlanta",state:"GA"},
  "30350":{lat:34.0003,lng:-84.3108,city:"Atlanta",state:"GA"},
  "30354":{lat:33.6503,lng:-84.3769,city:"Atlanta",state:"GA"},
  "30360":{lat:33.9403,lng:-84.2915,city:"Atlanta",state:"GA"},
  "30363":{lat:33.7903,lng:-84.4028,city:"Atlanta",state:"GA"},
  // Phoenix
  "85001":{lat:33.4484,lng:-112.0740,city:"Phoenix",state:"AZ"},
  "85003":{lat:33.4484,lng:-112.0740,city:"Phoenix",state:"AZ"},
  "85004":{lat:33.4501,lng:-112.0671,city:"Phoenix",state:"AZ"},
  "85006":{lat:33.4701,lng:-112.0409,city:"Phoenix",state:"AZ"},
  "85007":{lat:33.4384,lng:-112.0930,city:"Phoenix",state:"AZ"},
  "85008":{lat:33.4701,lng:-111.9919,city:"Phoenix",state:"AZ"},
  "85009":{lat:33.4484,lng:-112.1280,city:"Phoenix",state:"AZ"},
  "85012":{lat:33.5084,lng:-112.0730,city:"Phoenix",state:"AZ"},
  "85013":{lat:33.5084,lng:-112.0930,city:"Phoenix",state:"AZ"},
  "85014":{lat:33.5084,lng:-112.0530,city:"Phoenix",state:"AZ"},
  "85015":{lat:33.5094,lng:-112.0962,city:"Phoenix",state:"AZ"},
  "85016":{lat:33.5072,lng:-112.0318,city:"Phoenix",state:"AZ"},
  "85017":{lat:33.5084,lng:-112.1180,city:"Phoenix",state:"AZ"},
  "85018":{lat:33.5084,lng:-111.9819,city:"Phoenix",state:"AZ"},
  "85019":{lat:33.5284,lng:-112.1480,city:"Phoenix",state:"AZ"},
  "85020":{lat:33.5684,lng:-112.0530,city:"Phoenix",state:"AZ"},
  "85021":{lat:33.5684,lng:-112.0930,city:"Phoenix",state:"AZ"},
  "85022":{lat:33.6284,lng:-112.0130,city:"Phoenix",state:"AZ"},
  "85023":{lat:33.6484,lng:-112.0730,city:"Phoenix",state:"AZ"},
  "85024":{lat:33.6884,lng:-112.0130,city:"Phoenix",state:"AZ"},
  "85027":{lat:33.6884,lng:-112.0930,city:"Phoenix",state:"AZ"},
  "85028":{lat:33.5884,lng:-111.9819,city:"Phoenix",state:"AZ"},
  "85029":{lat:33.5984,lng:-112.1130,city:"Phoenix",state:"AZ"},
  "85031":{lat:33.4884,lng:-112.1680,city:"Phoenix",state:"AZ"},
  "85032":{lat:33.5884,lng:-111.9419,city:"Phoenix",state:"AZ"},
  "85033":{lat:33.4884,lng:-112.1980,city:"Phoenix",state:"AZ"},
  "85034":{lat:33.4284,lng:-112.0130,city:"Phoenix",state:"AZ"},
  "85035":{lat:33.4684,lng:-112.1580,city:"Phoenix",state:"AZ"},
  "85040":{lat:33.3684,lng:-112.0330,city:"Phoenix",state:"AZ"},
  "85041":{lat:33.3584,lng:-112.0730,city:"Phoenix",state:"AZ"},
  "85042":{lat:33.3584,lng:-112.0130,city:"Phoenix",state:"AZ"},
  "85043":{lat:33.3884,lng:-112.1480,city:"Phoenix",state:"AZ"},
  "85044":{lat:33.3301,lng:-111.9767,city:"Phoenix",state:"AZ"},
  "85045":{lat:33.3084,lng:-111.9719,city:"Phoenix",state:"AZ"},
  "85048":{lat:33.3084,lng:-111.9319,city:"Phoenix",state:"AZ"},
  "85050":{lat:33.6484,lng:-111.9619,city:"Phoenix",state:"AZ"},
  "85051":{lat:33.5484,lng:-112.1330,city:"Phoenix",state:"AZ"},
  "85053":{lat:33.6284,lng:-112.1130,city:"Phoenix",state:"AZ"},
  "85054":{lat:33.6884,lng:-111.9319,city:"Phoenix",state:"AZ"},
  "85083":{lat:33.7384,lng:-112.1030,city:"Phoenix",state:"AZ"},
  "85085":{lat:33.7384,lng:-112.0630,city:"Phoenix",state:"AZ"},
  "85086":{lat:33.8184,lng:-112.0630,city:"Phoenix",state:"AZ"},
  // Dallas
  "75201":{lat:32.7938,lng:-96.7999,city:"Dallas",state:"TX"},
  "75202":{lat:32.7805,lng:-96.8013,city:"Dallas",state:"TX"},
  "75203":{lat:32.7538,lng:-96.8099,city:"Dallas",state:"TX"},
  "75204":{lat:32.8005,lng:-96.7813,city:"Dallas",state:"TX"},
  "75205":{lat:32.8372,lng:-96.7913,city:"Dallas",state:"TX"},
  "75206":{lat:32.8272,lng:-96.7613,city:"Dallas",state:"TX"},
  "75207":{lat:32.7838,lng:-96.8213,city:"Dallas",state:"TX"},
  "75208":{lat:32.7538,lng:-96.8413,city:"Dallas",state:"TX"},
  "75209":{lat:32.8372,lng:-96.8313,city:"Dallas",state:"TX"},
  "75210":{lat:32.7738,lng:-96.7513,city:"Dallas",state:"TX"},
  "75211":{lat:32.7338,lng:-96.8813,city:"Dallas",state:"TX"},
  "75212":{lat:32.7838,lng:-96.8613,city:"Dallas",state:"TX"},
  "75214":{lat:32.8272,lng:-96.7313,city:"Dallas",state:"TX"},
  "75215":{lat:32.7538,lng:-96.7613,city:"Dallas",state:"TX"},
  "75216":{lat:32.7138,lng:-96.8013,city:"Dallas",state:"TX"},
  "75217":{lat:32.7138,lng:-96.6813,city:"Dallas",state:"TX"},
  "75218":{lat:32.8372,lng:-96.6913,city:"Dallas",state:"TX"},
  "75219":{lat:32.8235,lng:-96.8172,city:"Dallas",state:"TX"},
  "75220":{lat:32.8672,lng:-96.8713,city:"Dallas",state:"TX"},
  "75223":{lat:32.7972,lng:-96.7313,city:"Dallas",state:"TX"},
  "75224":{lat:32.7138,lng:-96.8413,city:"Dallas",state:"TX"},
  "75225":{lat:32.8672,lng:-96.7813,city:"Dallas",state:"TX"},
  "75226":{lat:32.7805,lng:-96.7613,city:"Dallas",state:"TX"},
  "75227":{lat:32.7738,lng:-96.6813,city:"Dallas",state:"TX"},
  "75228":{lat:32.8072,lng:-96.6613,city:"Dallas",state:"TX"},
  "75229":{lat:32.9072,lng:-96.8713,city:"Dallas",state:"TX"},
  "75230":{lat:32.9118,lng:-96.7843,city:"Dallas",state:"TX"},
  "75231":{lat:32.8772,lng:-96.7313,city:"Dallas",state:"TX"},
  "75232":{lat:32.6838,lng:-96.8413,city:"Dallas",state:"TX"},
  "75233":{lat:32.6938,lng:-96.8713,city:"Dallas",state:"TX"},
  "75234":{lat:32.9272,lng:-96.9013,city:"Dallas",state:"TX"},
  "75235":{lat:32.8172,lng:-96.8513,city:"Dallas",state:"TX"},
  "75236":{lat:32.6838,lng:-96.9013,city:"Dallas",state:"TX"},
  "75237":{lat:32.6638,lng:-96.8713,city:"Dallas",state:"TX"},
  "75238":{lat:32.8772,lng:-96.7013,city:"Dallas",state:"TX"},
  "75240":{lat:32.9372,lng:-96.7813,city:"Dallas",state:"TX"},
  "75241":{lat:32.6638,lng:-96.7813,city:"Dallas",state:"TX"},
  "75243":{lat:32.9072,lng:-96.7313,city:"Dallas",state:"TX"},
  "75244":{lat:32.9272,lng:-96.8313,city:"Dallas",state:"TX"},
  "75246":{lat:32.7972,lng:-96.7613,city:"Dallas",state:"TX"},
  "75247":{lat:32.8172,lng:-96.8713,city:"Dallas",state:"TX"},
  "75248":{lat:32.9772,lng:-96.8013,city:"Dallas",state:"TX"},
  "75249":{lat:32.6438,lng:-96.9413,city:"Dallas",state:"TX"},
  "75251":{lat:32.9272,lng:-96.7413,city:"Dallas",state:"TX"},
  "75252":{lat:33.0072,lng:-96.8013,city:"Dallas",state:"TX"},
  "75253":{lat:32.6638,lng:-96.6613,city:"Dallas",state:"TX"},
  // Denver
  "80202":{lat:39.7529,lng:-104.9997,city:"Denver",state:"CO"},
  "80203":{lat:39.7282,lng:-104.9780,city:"Denver",state:"CO"},
  "80204":{lat:39.7282,lng:-105.0097,city:"Denver",state:"CO"},
  "80205":{lat:39.7582,lng:-104.9580,city:"Denver",state:"CO"},
  "80206":{lat:39.7282,lng:-104.9480,city:"Denver",state:"CO"},
  "80207":{lat:39.7682,lng:-104.9180,city:"Denver",state:"CO"},
  "80209":{lat:39.7082,lng:-104.9680,city:"Denver",state:"CO"},
  "80210":{lat:39.6882,lng:-104.9680,city:"Denver",state:"CO"},
  "80211":{lat:39.7782,lng:-105.0097,city:"Denver",state:"CO"},
  "80212":{lat:39.7782,lng:-105.0497,city:"Denver",state:"CO"},
  "80214":{lat:39.7382,lng:-105.0697,city:"Denver",state:"CO"},
  "80215":{lat:39.7382,lng:-105.1097,city:"Denver",state:"CO"},
  "80216":{lat:39.7882,lng:-104.9580,city:"Denver",state:"CO"},
  "80218":{lat:39.7282,lng:-104.9680,city:"Denver",state:"CO"},
  "80219":{lat:39.7082,lng:-105.0297,city:"Denver",state:"CO"},
  "80220":{lat:39.7282,lng:-104.9180,city:"Denver",state:"CO"},
  "80221":{lat:39.8282,lng:-105.0097,city:"Denver",state:"CO"},
  "80222":{lat:39.6836,lng:-104.9397,city:"Denver",state:"CO"},
  "80223":{lat:39.7082,lng:-105.0097,city:"Denver",state:"CO"},
  "80224":{lat:39.6882,lng:-104.9080,city:"Denver",state:"CO"},
  "80226":{lat:39.7082,lng:-105.0897,city:"Denver",state:"CO"},
  "80227":{lat:39.6882,lng:-105.0897,city:"Denver",state:"CO"},
  "80228":{lat:39.6882,lng:-105.1297,city:"Denver",state:"CO"},
  "80229":{lat:39.8682,lng:-104.9680,city:"Denver",state:"CO"},
  "80230":{lat:39.7282,lng:-104.8980,city:"Denver",state:"CO"},
  "80231":{lat:39.6882,lng:-104.8780,city:"Denver",state:"CO"},
  "80232":{lat:39.6882,lng:-105.0497,city:"Denver",state:"CO"},
  "80233":{lat:39.8882,lng:-104.9580,city:"Denver",state:"CO"},
  "80234":{lat:39.9082,lng:-105.0097,city:"Denver",state:"CO"},
  "80235":{lat:39.6682,lng:-105.0697,city:"Denver",state:"CO"},
  "80236":{lat:39.6682,lng:-105.0297,city:"Denver",state:"CO"},
  "80237":{lat:39.6482,lng:-104.9297,city:"Denver",state:"CO"},
  "80238":{lat:39.7682,lng:-104.8780,city:"Denver",state:"CO"},
  "80239":{lat:39.7782,lng:-104.8580,city:"Denver",state:"CO"},
  "80246":{lat:39.7082,lng:-104.9480,city:"Denver",state:"CO"},
  "80247":{lat:39.7082,lng:-104.9080,city:"Denver",state:"CO"},
  "80249":{lat:39.7882,lng:-104.8380,city:"Denver",state:"CO"},
  "80264":{lat:39.7429,lng:-104.9878,city:"Denver",state:"CO"},
  // San Diego
  "92101":{lat:32.7291,lng:-117.1594,city:"San Diego",state:"CA"},
  "92102":{lat:32.7091,lng:-117.1294,city:"San Diego",state:"CA"},
  "92103":{lat:32.7479,lng:-117.1614,city:"San Diego",state:"CA"},
  "92104":{lat:32.7291,lng:-117.1294,city:"San Diego",state:"CA"},
  "92105":{lat:32.7291,lng:-117.0994,city:"San Diego",state:"CA"},
  "92106":{lat:32.7091,lng:-117.2294,city:"San Diego",state:"CA"},
  "92107":{lat:32.7391,lng:-117.2394,city:"San Diego",state:"CA"},
  "92108":{lat:32.7720,lng:-117.1558,city:"San Diego",state:"CA"},
  "92109":{lat:32.7991,lng:-117.2294,city:"San Diego",state:"CA"},
  "92110":{lat:32.7591,lng:-117.2094,city:"San Diego",state:"CA"},
  "92111":{lat:32.7891,lng:-117.1694,city:"San Diego",state:"CA"},
  "92113":{lat:32.6991,lng:-117.1094,city:"San Diego",state:"CA"},
  "92114":{lat:32.6891,lng:-117.0794,city:"San Diego",state:"CA"},
  "92115":{lat:32.7691,lng:-117.0694,city:"San Diego",state:"CA"},
  "92116":{lat:32.7591,lng:-117.1194,city:"San Diego",state:"CA"},
  "92117":{lat:32.8191,lng:-117.1994,city:"San Diego",state:"CA"},
  "92118":{lat:32.6491,lng:-117.1694,city:"Coronado",state:"CA"},
  "92119":{lat:32.8091,lng:-117.0394,city:"San Diego",state:"CA"},
  "92120":{lat:32.7891,lng:-117.0594,city:"San Diego",state:"CA"},
  "92121":{lat:32.8991,lng:-117.2094,city:"San Diego",state:"CA"},
  "92122":{lat:32.8591,lng:-117.2094,city:"San Diego",state:"CA"},
  "92123":{lat:32.8191,lng:-117.1294,city:"San Diego",state:"CA"},
  "92124":{lat:32.8191,lng:-117.0794,city:"San Diego",state:"CA"},
  "92126":{lat:32.9091,lng:-117.1394,city:"San Diego",state:"CA"},
  "92127":{lat:33.0191,lng:-117.1094,city:"San Diego",state:"CA"},
  "92128":{lat:33.0391,lng:-117.0794,city:"San Diego",state:"CA"},
  "92129":{lat:32.9591,lng:-117.1294,city:"San Diego",state:"CA"},
  "92130":{lat:32.9491,lng:-117.2294,city:"San Diego",state:"CA"},
  "92131":{lat:32.9191,lng:-117.0894,city:"San Diego",state:"CA"},
  "92132":{lat:32.7291,lng:-117.1994,city:"San Diego",state:"CA"},
  "92134":{lat:32.7291,lng:-117.1494,city:"San Diego",state:"CA"},
  "92139":{lat:32.6691,lng:-117.0394,city:"San Diego",state:"CA"},
  "92140":{lat:32.7491,lng:-117.1994,city:"San Diego",state:"CA"},
  "92154":{lat:32.5691,lng:-117.0594,city:"San Diego",state:"CA"},
  // Las Vegas
  "89101":{lat:36.1716,lng:-115.1391,city:"Las Vegas",state:"NV"},
  "89102":{lat:36.1516,lng:-115.1791,city:"Las Vegas",state:"NV"},
  "89103":{lat:36.1316,lng:-115.1991,city:"Las Vegas",state:"NV"},
  "89104":{lat:36.1716,lng:-115.1091,city:"Las Vegas",state:"NV"},
  "89106":{lat:36.1916,lng:-115.1691,city:"Las Vegas",state:"NV"},
  "89107":{lat:36.1916,lng:-115.2091,city:"Las Vegas",state:"NV"},
  "89108":{lat:36.2216,lng:-115.1991,city:"Las Vegas",state:"NV"},
  "89109":{lat:36.1216,lng:-115.1691,city:"Las Vegas",state:"NV"},
  "89110":{lat:36.1716,lng:-115.0591,city:"Las Vegas",state:"NV"},
  "89115":{lat:36.2316,lng:-115.0691,city:"Las Vegas",state:"NV"},
  "89117":{lat:36.1516,lng:-115.2691,city:"Las Vegas",state:"NV"},
  "89118":{lat:36.1116,lng:-115.1791,city:"Las Vegas",state:"NV"},
  "89119":{lat:36.1014,lng:-115.1348,city:"Las Vegas",state:"NV"},
  "89120":{lat:36.0916,lng:-115.1091,city:"Las Vegas",state:"NV"},
  "89121":{lat:36.1116,lng:-115.0791,city:"Las Vegas",state:"NV"},
  "89122":{lat:36.1116,lng:-115.0491,city:"Las Vegas",state:"NV"},
  "89123":{lat:36.0616,lng:-115.1491,city:"Las Vegas",state:"NV"},
  "89128":{lat:36.1968,lng:-115.2280,city:"Las Vegas",state:"NV"},
  "89129":{lat:36.2316,lng:-115.2691,city:"Las Vegas",state:"NV"},
  "89130":{lat:36.2616,lng:-115.2091,city:"Las Vegas",state:"NV"},
  "89131":{lat:36.2916,lng:-115.2091,city:"Las Vegas",state:"NV"},
  "89134":{lat:36.2216,lng:-115.2991,city:"Las Vegas",state:"NV"},
  "89135":{lat:36.1716,lng:-115.3291,city:"Las Vegas",state:"NV"},
  "89138":{lat:36.2016,lng:-115.3091,city:"Las Vegas",state:"NV"},
  "89139":{lat:36.0316,lng:-115.2091,city:"Las Vegas",state:"NV"},
  "89141":{lat:35.9916,lng:-115.1791,city:"Las Vegas",state:"NV"},
  "89143":{lat:36.3116,lng:-115.2691,city:"Las Vegas",state:"NV"},
  "89144":{lat:36.1916,lng:-115.3091,city:"Las Vegas",state:"NV"},
  "89145":{lat:36.1716,lng:-115.2691,city:"Las Vegas",state:"NV"},
  "89146":{lat:36.1516,lng:-115.2291,city:"Las Vegas",state:"NV"},
  "89147":{lat:36.1116,lng:-115.2691,city:"Las Vegas",state:"NV"},
  "89148":{lat:36.0816,lng:-115.2691,city:"Las Vegas",state:"NV"},
  "89149":{lat:36.2616,lng:-115.2891,city:"Las Vegas",state:"NV"},
  "89166":{lat:36.3516,lng:-115.3491,city:"Las Vegas",state:"NV"},
  "89169":{lat:36.1116,lng:-115.1391,city:"Las Vegas",state:"NV"},
  // Portland
  "97201":{lat:45.5231,lng:-122.6765,city:"Portland",state:"OR"},
  "97202":{lat:45.4918,lng:-122.6465,city:"Portland",state:"OR"},
  "97203":{lat:45.5918,lng:-122.7565,city:"Portland",state:"OR"},
  "97204":{lat:45.5218,lng:-122.6765,city:"Portland",state:"OR"},
  "97205":{lat:45.5218,lng:-122.6965,city:"Portland",state:"OR"},
  "97206":{lat:45.4818,lng:-122.6065,city:"Portland",state:"OR"},
  "97207":{lat:45.5218,lng:-122.6765,city:"Portland",state:"OR"},
  "97208":{lat:45.5218,lng:-122.6765,city:"Portland",state:"OR"},
  "97209":{lat:45.5318,lng:-122.6965,city:"Portland",state:"OR"},
  "97210":{lat:45.5418,lng:-122.7165,city:"Portland",state:"OR"},
  "97211":{lat:45.5818,lng:-122.6265,city:"Portland",state:"OR"},
  "97212":{lat:45.5518,lng:-122.6365,city:"Portland",state:"OR"},
  "97213":{lat:45.5318,lng:-122.5865,city:"Portland",state:"OR"},
  "97214":{lat:45.5188,lng:-122.6509,city:"Portland",state:"OR"},
  "97215":{lat:45.5018,lng:-122.5965,city:"Portland",state:"OR"},
  "97216":{lat:45.5018,lng:-122.5565,city:"Portland",state:"OR"},
  "97217":{lat:45.5918,lng:-122.6765,city:"Portland",state:"OR"},
  "97218":{lat:45.5618,lng:-122.5865,city:"Portland",state:"OR"},
  "97219":{lat:45.4618,lng:-122.7165,city:"Portland",state:"OR"},
  "97220":{lat:45.5518,lng:-122.5365,city:"Portland",state:"OR"},
  "97221":{lat:45.4918,lng:-122.7465,city:"Portland",state:"OR"},
  "97222":{lat:45.4418,lng:-122.6165,city:"Milwaukie",state:"OR"},
  "97223":{lat:45.4518,lng:-122.7702,city:"Portland",state:"OR"},
  "97224":{lat:45.4118,lng:-122.7865,city:"Portland",state:"OR"},
  "97225":{lat:45.5118,lng:-122.7765,city:"Portland",state:"OR"},
  "97227":{lat:45.5418,lng:-122.6765,city:"Portland",state:"OR"},
  "97229":{lat:45.5518,lng:-122.8265,city:"Portland",state:"OR"},
  "97230":{lat:45.5518,lng:-122.5065,city:"Portland",state:"OR"},
  "97231":{lat:45.6118,lng:-122.7965,city:"Portland",state:"OR"},
  "97232":{lat:45.5218,lng:-122.6465,city:"Portland",state:"OR"},
  "97233":{lat:45.5018,lng:-122.4865,city:"Portland",state:"OR"},
  "97236":{lat:45.4818,lng:-122.4965,city:"Portland",state:"OR"},
  "97239":{lat:45.5018,lng:-122.6965,city:"Portland",state:"OR"},
  "97266":{lat:45.4718,lng:-122.5565,city:"Portland",state:"OR"},
};

function haversine(lat1,lon1,lat2,lon2) {
  const R=3958.8,dl=(lat2-lat1)*Math.PI/180,dn=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dl/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dn/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
function ago(ts){if(!ts)return"";const s=Math.floor((Date.now()-ts)/1000);if(s<60)return`${s}s ago`;if(s<3600)return`${Math.floor(s/60)}m ago`;if(s<86400)return`${Math.floor(s/3600)}h ago`;return`${Math.floor(s/86400)}d ago`;}
function left(ts,ms){if(!ts||!ms)return null;const r=ms-(Date.now()-ts);if(r<=0)return null;const m=Math.floor(r/60000);if(m<60)return`${m}m`;if(m<1440)return`${Math.floor(m/60)}h ${m%60?m%60+"m":""}`.trim();const d=Math.floor(m/1440);return`${d}d`;}
function effSt(store){if(!store.lastReport||!store.status||store.status===STATUS.UNKNOWN)return STATUS.UNKNOWN;const rm=store.status===STATUS.DOWN?store.downDuration:RESET_MS[store.status];if(rm&&Date.now()-store.lastReport>rm)return STATUS.UNKNOWN;return store.status;}

const STORES = [
  {id:"nyc1",name:"Staples",address:"1280 Lexington Ave",city:"New York",state:"NY",zip:"10028",lat:40.7817,lng:-73.9549},
  {id:"nyc2",name:"Staples",address:"699 6th Ave",city:"New York",state:"NY",zip:"10010",lat:40.7421,lng:-73.9944},
  {id:"nyc3",name:"Staples",address:"200 Water St",city:"New York",state:"NY",zip:"10038",lat:40.7075,lng:-74.0024},
  {id:"bk1", name:"Staples",address:"345 Adams St",city:"Brooklyn",state:"NY",zip:"11201",lat:40.6928,lng:-73.9903},
  {id:"la1", name:"Staples",address:"6450 Sepulveda Blvd",city:"Van Nuys",state:"CA",zip:"91411",lat:34.0019,lng:-118.4491},
  {id:"la2", name:"Staples",address:"11260 Santa Monica Blvd",city:"Los Angeles",state:"CA",zip:"90025",lat:34.0481,lng:-118.4547},
  {id:"la3", name:"Staples",address:"3757 Santa Rosalia Dr",city:"Los Angeles",state:"CA",zip:"90008",lat:34.0048,lng:-118.3508},
  {id:"chi1",name:"Staples",address:"1130 N Clark St",city:"Chicago",state:"IL",zip:"60610",lat:41.9028,lng:-87.6311},
  {id:"chi2",name:"Staples",address:"2550 N Elston Ave",city:"Chicago",state:"IL",zip:"60647",lat:41.9298,lng:-87.6879},
  {id:"hou1",name:"Staples",address:"9706 Westheimer Rd",city:"Houston",state:"TX",zip:"77063",lat:29.7370,lng:-95.5013},
  {id:"hou2",name:"Staples",address:"2040 S Shepherd Dr",city:"Houston",state:"TX",zip:"77019",lat:29.7403,lng:-95.4063},
  {id:"phi1",name:"Staples",address:"1701 JFK Blvd",city:"Philadelphia",state:"PA",zip:"19103",lat:39.9533,lng:-75.1657},
  {id:"phi2",name:"Staples",address:"4000 Monument Rd",city:"Philadelphia",state:"PA",zip:"19131",lat:39.9840,lng:-75.2286},
  {id:"phx1",name:"Staples",address:"1940 W Camelback Rd",city:"Phoenix",state:"AZ",zip:"85015",lat:33.5094,lng:-112.0962},
  {id:"phx2",name:"Staples",address:"5020 E Ray Rd",city:"Phoenix",state:"AZ",zip:"85044",lat:33.3301,lng:-111.9767},
  {id:"dal1",name:"Staples",address:"3839 Oak Lawn Ave",city:"Dallas",state:"TX",zip:"75219",lat:32.8235,lng:-96.8172},
  {id:"dal2",name:"Staples",address:"4040 Belt Line Rd",city:"Addison",state:"TX",zip:"75001",lat:32.9591,lng:-96.8218},
  {id:"sd1", name:"Staples",address:"7510 Hazard Center Dr",city:"San Diego",state:"CA",zip:"92108",lat:32.7720,lng:-117.1558},
  {id:"sj1", name:"Staples",address:"1600 Saratoga Ave",city:"San Jose",state:"CA",zip:"95129",lat:37.3061,lng:-121.9779},
  {id:"bos1",name:"Staples",address:"1 Federal St",city:"Boston",state:"MA",zip:"02110",lat:42.3549,lng:-71.0575},
  {id:"bos2",name:"Staples",address:"395 Washington St",city:"Brighton",state:"MA",zip:"02135",lat:42.3494,lng:-71.1571},
  {id:"sea1",name:"Staples",address:"10002 Aurora Ave N",city:"Seattle",state:"WA",zip:"98133",lat:47.7009,lng:-122.3450},
  {id:"sea2",name:"Staples",address:"15600 NE 8th St",city:"Bellevue",state:"WA",zip:"98008",lat:47.6183,lng:-122.1278},
  {id:"mia1",name:"Staples",address:"6940 SW 40th St",city:"Miami",state:"FL",zip:"33155",lat:25.7326,lng:-80.3161},
  {id:"mia2",name:"Staples",address:"7900 NW 27th Ave",city:"Miami",state:"FL",zip:"33147",lat:25.8436,lng:-80.2316},
  {id:"atl1",name:"Staples",address:"2525 Piedmont Rd NE",city:"Atlanta",state:"GA",zip:"30324",lat:33.8435,lng:-84.3645},
  {id:"den1",name:"Staples",address:"1350 S Colorado Blvd",city:"Denver",state:"CO",zip:"80222",lat:39.6836,lng:-104.9397},
  {id:"min1",name:"Staples",address:"3330 Hennepin Ave S",city:"Minneapolis",state:"MN",zip:"55408",lat:44.9338,lng:-93.2991},
  {id:"lv1", name:"Staples",address:"4001 S Maryland Pkwy",city:"Las Vegas",state:"NV",zip:"89119",lat:36.1014,lng:-115.1348},
  {id:"por1",name:"Staples",address:"9700 SW Washington Square Rd",city:"Portland",state:"OR",zip:"97223",lat:45.4518,lng:-122.7702},
];

function Toast({msg}){return(<div style={{position:"fixed",bottom:32,left:"50%",transform:"translateX(-50%)",background:"#0f172a",borderRadius:12,padding:"12px 24px",color:"#fff",fontSize:13,fontWeight:600,boxShadow:"0 8px 32px rgba(0,0,0,0.2)",whiteSpace:"nowrap",zIndex:999,fontFamily:"system-ui"}}>{msg}</div>);}

export default function App(){
  const [stores,setStores]=useState(STORES.map(s=>({...s,status:STATUS.UNKNOWN,lastReport:null,reportCount:0,downDuration:null,note:""})));
  const [ads,setAds]=useState([]);
  const [view,setView]=useState("home");
  const [selectedId,setSelectedId]=useState(null);
  const [step,setStep]=useState("status");
  const [pendSt,setPendSt]=useState(null);
  const [pendDur,setPendDur]=useState(null);
  const [noteText,setNoteText]=useState("");
  const [zipInput,setZipInput]=useState("");
  const [searchText,setSearchText]=useState("");
  const [refLoc,setRefLoc]=useState(null);
  const [geoLoading,setGeoLoading]=useState(false);
  const [toast,setToast]=useState(null);
  const [loading,setLoading]=useState(true);
  const [adminPw,setAdminPw]=useState("");
  const [adminErr,setAdminErr]=useState("");
  const [adminTab,setAdminTab]=useState("stores");
  const [editId,setEditId]=useState(null);
  const [editVals,setEditVals]=useState({});
  const [newSF,setNewSF]=useState({name:"Staples",address:"",city:"",state:"",zip:""});
  const [adFrm,setAdFrm]=useState({headline:"",subtext:"",cta:"",url:"",active:true});
  const [editAdIdx,setEditAdIdx]=useState(null);
  const [,setTick]=useState(0);

  useEffect(()=>{const t=setInterval(()=>setTick(x=>x+1),15000);return()=>clearInterval(t);},[]);

  const loadAll=useCallback(async()=>{
    try{const keys=await window.storage.list("s:",true);if(keys?.keys?.length){const up={};await Promise.all(keys.keys.map(async k=>{try{const r=await window.storage.get(k,true);if(r)up[k.replace("s:","")]=JSON.parse(r.value);}catch{}}));setStores(prev=>prev.map(s=>up[s.id]?{...s,...up[s.id]}:s));}}catch{}
    try{const r=await window.storage.get("ads2",true);if(r)setAds(JSON.parse(r.value));}catch{}
    setLoading(false);
  },[]);
  useEffect(()=>{loadAll();const t=setInterval(loadAll,30000);return()=>clearInterval(t);},[loadAll]);

  function showToast(msg){setToast(msg);setTimeout(()=>setToast(null),2500);}
  async function saveStoreData(id,data){setStores(prev=>prev.map(s=>s.id===id?{...s,...data}:s));try{await window.storage.set(`s:${id}`,JSON.stringify(data),true);}catch{}}

  function handleZip(){
    const z=zipInput.trim().replace(/\D/g,"").slice(0,5);
    if(z.length!==5){showToast("Enter a valid 5-digit ZIP");return;}
    const entry=ZIP_DB[z];
    if(entry){setRefLoc({...entry,label:`ZIP ${z} · ${entry.city}, ${entry.state}`});showToast(`📍 Showing stores near ${entry.city}, ${entry.state}`);}
    else showToast("ZIP not found — try a nearby ZIP");
  }

  function handleGeo(){
    if(!navigator.geolocation){showToast("Location not supported");return;}
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(p=>{setRefLoc({lat:p.coords.latitude,lng:p.coords.longitude,label:"Your location"});setGeoLoading(false);showToast("📍 Sorted by distance");},()=>{showToast("Location denied");setGeoLoading(false);});
  }

  const selected=stores.find(s=>s.id===selectedId);
  let displayed=[...stores];
  if(searchText.trim()){const q=searchText.toLowerCase();displayed=displayed.filter(s=>[s.address,s.city,s.state,s.zip,s.name].some(f=>f?.toLowerCase().includes(q)));}
  if(refLoc)displayed=[...displayed].map(s=>({...s,_d:s.lat?haversine(refLoc.lat,refLoc.lng,s.lat,s.lng):9999})).sort((a,b)=>a._d-b._d);

  const activeAd=ads.find(a=>a.active);
  const upCount=stores.filter(s=>effSt(s)===STATUS.UP).length;
  const downCount=stores.filter(s=>effSt(s)===STATUS.DOWN).length;

  const iS={width:"100%",boxSizing:"border-box",border:"1.5px solid #e2e8f0",borderRadius:10,padding:"11px 14px",fontSize:14,fontFamily:"system-ui",outline:"none",background:"#f8fafc",color:"#0f172a"};

  // ── ADMIN LOGIN ──
  if(view==="adminLogin"){return(
    <div style={{minHeight:"100vh",background:"#f8fafc",fontFamily:"system-ui",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:20,padding:32,width:"100%",maxWidth:320,boxShadow:"0 8px 40px rgba(0,0,0,0.08)"}}>
        <button onClick={()=>setView("home")} style={{fontSize:12,color:"#94a3b8",background:"none",border:"none",cursor:"pointer",marginBottom:20,padding:0,fontFamily:"system-ui"}}>← Back</button>
        <div style={{fontSize:10,letterSpacing:4,color:"#94a3b8",fontWeight:700,marginBottom:6}}>ADMIN</div>
        <div style={{fontSize:22,fontWeight:900,marginBottom:24,color:"#0f172a"}}>Control Panel</div>
        <input type="password" placeholder="Password" value={adminPw} onChange={e=>{setAdminPw(e.target.value);setAdminErr("");}} onKeyDown={e=>e.key==="Enter"&&(adminPw===ADMIN_PASSWORD?setView("admin"):setAdminErr("Wrong password"))} style={{...iS,marginBottom:adminErr?6:16,borderColor:adminErr?"#fecdd3":"#e2e8f0"}}/>
        {adminErr&&<div style={{fontSize:12,color:"#dc2626",marginBottom:12}}>{adminErr}</div>}
        <button onClick={()=>adminPw===ADMIN_PASSWORD?setView("admin"):setAdminErr("Wrong password")} style={{width:"100%",padding:13,background:"#0f172a",border:"none",borderRadius:12,color:"#fff",fontWeight:800,fontSize:15,cursor:"pointer",fontFamily:"system-ui"}}>Enter</button>
      </div>
    </div>
  );}

  // ── ADMIN PANEL ──
  if(view==="admin"){
    const card={background:"#fff",border:"1px solid #e2e8f0",borderRadius:12,padding:16,marginBottom:10};
    const Btn=({c="#16a34a",children,onClick})=><button onClick={onClick} style={{padding:"7px 14px",background:"transparent",border:`1.5px solid ${c}`,borderRadius:8,color:c,fontSize:12,cursor:"pointer",fontFamily:"system-ui",fontWeight:600}}>{children}</button>;
    return(
      <div style={{minHeight:"100vh",background:"#f8fafc",fontFamily:"system-ui",color:"#0f172a"}}>
        <div style={{background:"#fff",borderBottom:"1px solid #e2e8f0",padding:"14px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,zIndex:10}}>
          <div style={{fontWeight:800,fontSize:18}}>Admin Panel</div>
          <button onClick={()=>setView("home")} style={{padding:"8px 16px",background:"#f1f5f9",border:"1px solid #e2e8f0",borderRadius:8,color:"#64748b",fontSize:12,cursor:"pointer",fontFamily:"system-ui",fontWeight:600}}>← Back to App</button>
        </div>
        <div style={{maxWidth:640,margin:"0 auto",padding:"20px 16px 80px"}}>
          <div style={{display:"flex",background:"#f1f5f9",borderRadius:10,padding:4,marginBottom:20,gap:4}}>
            {["stores","ads"].map(t=><button key={t} onClick={()=>setAdminTab(t)} style={{flex:1,padding:9,background:adminTab===t?"#fff":"transparent",border:"none",borderRadius:8,color:adminTab===t?"#0f172a":"#94a3b8",fontSize:12,cursor:"pointer",fontFamily:"system-ui",fontWeight:700,letterSpacing:1,boxShadow:adminTab===t?"0 1px 3px rgba(0,0,0,0.08)":"none"}}>{t.toUpperCase()}</button>)}
          </div>
          {adminTab==="stores"&&<>
            {stores.map(s=>{const st=effSt(s);const cfg=STATUS_CONFIG[st];return editId===s.id?(
              <div key={s.id} style={card}>
                {["name","address","city","state","zip"].map(f=><input key={f} placeholder={f} value={editVals[f]??s[f]??""} onChange={e=>setEditVals(p=>({...p,[f]:e.target.value}))} style={{...iS,marginBottom:8}}/>)}
                <div style={{display:"flex",gap:8}}><Btn onClick={()=>{setStores(prev=>prev.map(x=>x.id===s.id?{...x,...editVals}:x));setEditId(null);showToast("Saved!");}}>Save</Btn><Btn c="#94a3b8" onClick={()=>setEditId(null)}>Cancel</Btn></div>
              </div>
            ):(
              <div key={s.id} style={{...card,display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}>
                <div style={{flex:1,minWidth:0}}><div style={{fontWeight:700,fontSize:13,marginBottom:2}}>{s.address}</div><div style={{fontSize:11,color:"#64748b"}}>{s.city}, {s.state} {s.zip}</div><span style={{display:"inline-block",marginTop:6,fontSize:10,fontWeight:700,color:cfg.color,background:cfg.bg,border:`1px solid ${cfg.border}`,borderRadius:20,padding:"2px 8px"}}>{cfg.label}</span></div>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",justifyContent:"flex-end"}}><Btn c="#64748b" onClick={()=>{setEditId(s.id);setEditVals({});}}>Edit</Btn>{st!==STATUS.UNKNOWN&&<Btn c="#d97706" onClick={()=>saveStoreData(s.id,{status:STATUS.UNKNOWN,lastReport:null,note:"",reportCount:s.reportCount||0})}>Clear</Btn>}<Btn c="#dc2626" onClick={()=>{if(window.confirm("Delete?"))setStores(prev=>prev.filter(x=>x.id!==s.id));}}>Del</Btn></div>
              </div>
            );})}
            <div style={{...card,border:"1px dashed #cbd5e1",background:"#f8fafc"}}>
              <div style={{fontSize:11,fontWeight:700,letterSpacing:3,color:"#94a3b8",marginBottom:12}}>ADD STORE</div>
              {[{k:"name",ph:"Name"},{k:"address",ph:"Address"},{k:"city",ph:"City"},{k:"state",ph:"State"},{k:"zip",ph:"ZIP"}].map(f=><input key={f.k} placeholder={f.ph} value={newSF[f.k]} onChange={e=>setNewSF(p=>({...p,[f.k]:e.target.value}))} style={{...iS,marginBottom:8}}/>)}
              <Btn onClick={()=>{if(!newSF.address.trim())return;const ns={id:"u"+Date.now(),...newSF,lat:ZIP_DB[newSF.zip]?.lat||0,lng:ZIP_DB[newSF.zip]?.lng||0,status:STATUS.UNKNOWN,lastReport:null,reportCount:0,downDuration:null,note:""};setStores(prev=>[...prev,ns]);setNewSF({name:"Staples",address:"",city:"",state:"",zip:""});showToast("Store added!");}}>+ Add Store</Btn>
            </div>
          </>}
          {adminTab==="ads"&&<>
            {ads.length===0&&<div style={{color:"#94a3b8",fontSize:13,marginBottom:16}}>No ads yet.</div>}
            {ads.map((ad,i)=>editAdIdx===i?(
              <div key={i} style={card}>
                {[{k:"headline",ph:"Headline"},{k:"subtext",ph:"Subtext"},{k:"cta",ph:"Button text"},{k:"url",ph:"Link URL"}].map(f=><input key={f.k} placeholder={f.ph} value={ad[f.k]||""} onChange={e=>{const u=[...ads];u[i]={...u[i],[f.k]:e.target.value};setAds(u);}} style={{...iS,marginBottom:8}}/>)}
                <label style={{display:"flex",alignItems:"center",gap:8,fontSize:13,color:"#64748b",marginBottom:12,cursor:"pointer"}}><input type="checkbox" checked={!!ad.active} onChange={e=>{const u=[...ads];u[i]={...u[i],active:e.target.checked};setAds(u);}}/> Active</label>
                <div style={{display:"flex",gap:8}}><Btn onClick={async()=>{await window.storage.set("ads2",JSON.stringify(ads),true).catch(()=>{});setEditAdIdx(null);showToast("Saved!");}}>Save</Btn><Btn c="#94a3b8" onClick={()=>setEditAdIdx(null)}>Cancel</Btn></div>
              </div>
            ):(
              <div key={i} style={{...card,display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}>
                <div><div style={{fontWeight:700}}>{ad.headline||"(untitled)"}</div><div style={{fontSize:11,color:ad.active?"#16a34a":"#94a3b8",marginTop:4}}>{ad.active?"● Active":"○ Inactive"}</div></div>
                <div style={{display:"flex",gap:6}}><Btn c="#64748b" onClick={()=>setEditAdIdx(i)}>Edit</Btn><Btn c="#dc2626" onClick={async()=>{const u=ads.filter((_,j)=>j!==i);setAds(u);await window.storage.set("ads2",JSON.stringify(u),true).catch(()=>{});showToast("Deleted");}}>Del</Btn></div>
              </div>
            ))}
            <div style={{...card,border:"1px dashed #cbd5e1",background:"#f8fafc"}}>
              <div style={{fontSize:11,fontWeight:700,letterSpacing:3,color:"#94a3b8",marginBottom:12}}>NEW AD</div>
              {[{k:"headline",ph:"Headline"},{k:"subtext",ph:"Subtext"},{k:"cta",ph:"Button text"},{k:"url",ph:"Click URL"}].map(f=><input key={f.k} placeholder={f.ph} value={adFrm[f.k]||""} onChange={e=>setAdFrm(p=>({...p,[f.k]:e.target.value}))} style={{...iS,marginBottom:8}}/>)}
              <label style={{display:"flex",alignItems:"center",gap:8,fontSize:13,color:"#64748b",marginBottom:12,cursor:"pointer"}}><input type="checkbox" checked={!!adFrm.active} onChange={e=>setAdFrm(p=>({...p,active:e.target.checked}))}/> Show in app immediately</label>
              <Btn onClick={async()=>{if(!adFrm.headline.trim())return;const u=[...ads,{...adFrm}];setAds(u);await window.storage.set("ads2",JSON.stringify(u),true).catch(()=>{});setAdFrm({headline:"",subtext:"",cta:"",url:"",active:true});showToast("Ad added!");}}>+ Add Ad</Btn>
            </div>
          </>}
        </div>
      </div>
    );
  }

  // ── DETAIL VIEW ──
  if(view==="detail"&&selected){
    const st=effSt(selected);const cfg=STATUS_CONFIG[st];
    const resetMs=selected.status===STATUS.DOWN?selected.downDuration:RESET_MS[selected.status];
    const remaining=left(selected.lastReport,resetMs);
    return(
      <div style={{minHeight:"100vh",background:"#f8fafc",fontFamily:"system-ui",color:"#0f172a"}}>
        <div style={{background:"#fff",borderBottom:"1px solid #e2e8f0",padding:"14px 20px",display:"flex",alignItems:"center",gap:12,position:"sticky",top:0,zIndex:10}}>
          <button onClick={()=>{setView("home");setStep("status");setPendSt(null);setPendDur(null);setNoteText("");}} style={{width:36,height:36,borderRadius:"50%",background:"#f1f5f9",border:"1px solid #e2e8f0",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:18,flexShrink:0,fontFamily:"system-ui"}}>←</button>
          <div style={{flex:1,minWidth:0}}><div style={{fontWeight:700,fontSize:15,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{selected.address}</div><div style={{fontSize:12,color:"#64748b"}}>{selected.city}, {selected.state} {selected.zip}</div></div>
        </div>
        <div style={{maxWidth:540,margin:"0 auto",padding:"20px 16px 80px"}}>
          {/* Status card */}
          <div style={{background:cfg.bg,border:`1.5px solid ${cfg.border}`,borderRadius:20,padding:"28px 24px",marginBottom:20,textAlign:"center",position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:0,left:0,right:0,height:4,background:cfg.dot}}/>
            <div style={{fontSize:52,marginBottom:10}}>{st===STATUS.UP?"✅":st===STATUS.DOWN?"🔴":st===STATUS.BUSY?"🟡":"📦"}</div>
            <div style={{fontSize:26,fontWeight:900,color:cfg.color,marginBottom:4}}>{cfg.label}</div>
            {selected.lastReport&&st!==STATUS.UNKNOWN&&<div style={{fontSize:13,color:"#94a3b8",marginBottom:8}}>Reported {ago(selected.lastReport)}</div>}
            {remaining&&<div style={{display:"inline-block",background:"#fff",border:`1px solid ${cfg.border}`,borderRadius:20,padding:"4px 14px",fontSize:12,color:cfg.color,fontWeight:600}}>Resets in {remaining}</div>}
            {selected.note&&st!==STATUS.UNKNOWN&&<div style={{marginTop:14,padding:"10px 14px",background:"rgba(255,255,255,0.7)",borderRadius:10,fontSize:13,color:"#475569",fontStyle:"italic",textAlign:"left"}}>💬 "{selected.note}"</div>}
            {selected.reportCount>0&&<div style={{marginTop:10,fontSize:11,color:"#94a3b8"}}>{selected.reportCount} community report{selected.reportCount!==1?"s":""}</div>}
          </div>
          {/* Report */}
          <div style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:20,padding:20}}>
            <div style={{fontSize:11,fontWeight:700,letterSpacing:2,color:"#94a3b8",marginBottom:16,textTransform:"uppercase"}}>{step==="status"?"Update Status":step==="dur"?"How Long Is It Down?":"Confirm & Submit"}</div>
            {step==="status"&&(
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {[{s:STATUS.UP,emoji:"✅",label:"It's Working",sub:"Kiosk is up and running",c:"#16a34a",bg:"#f0fdf4",bd:"#bbf7d0"},
                  {s:STATUS.DOWN,emoji:"🔴",label:"It's Down",sub:"Kiosk is not working",c:"#dc2626",bg:"#fff1f2",bd:"#fecdd3"},
                  {s:STATUS.BUSY,emoji:"🟡",label:"Long Wait",sub:"Working but busy (~30 min)",c:"#d97706",bg:"#fffbeb",bd:"#fde68a"},
                ].map(o=>(
                  <button key={o.s} onClick={()=>{setPendSt(o.s);setStep(o.s===STATUS.DOWN?"dur":"note");}} style={{display:"flex",alignItems:"center",gap:14,padding:"14px 16px",background:o.bg,border:`1.5px solid ${o.bd}`,borderRadius:14,cursor:"pointer",textAlign:"left",fontFamily:"system-ui"}}>
                    <span style={{fontSize:26}}>{o.emoji}</span>
                    <div><div style={{fontWeight:700,fontSize:15,color:o.c}}>{o.label}</div><div style={{fontSize:12,color:"#94a3b8",marginTop:1}}>{o.sub}</div></div>
                    <span style={{marginLeft:"auto",fontSize:20,color:o.c,opacity:0.4}}>›</span>
                  </button>
                ))}
              </div>
            )}
            {step==="dur"&&(<>
              <p style={{fontSize:13,color:"#64748b",marginBottom:14,margin:"0 0 14px"}}>What does the sign or screen say?</p>
              <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:14}}>
                {DOWN_OPTS.map(o=><button key={o.ms} onClick={()=>{setPendDur(o.ms);setStep("note");}} style={{padding:"9px 14px",background:"#fff1f2",border:"1.5px solid #fecdd3",borderRadius:10,color:"#dc2626",fontSize:13,cursor:"pointer",fontFamily:"system-ui",fontWeight:600}}>{o.label}</button>)}
              </div>
              <button onClick={()=>setStep("status")} style={{fontSize:12,color:"#94a3b8",background:"none",border:"none",cursor:"pointer",fontFamily:"system-ui",padding:0}}>← Back</button>
            </>)}
            {step==="note"&&(<>
              <div style={{display:"inline-flex",alignItems:"center",gap:6,padding:"5px 12px",background:STATUS_CONFIG[pendSt].bg,border:`1px solid ${STATUS_CONFIG[pendSt].border}`,borderRadius:20,marginBottom:14}}>
                <span style={{width:7,height:7,borderRadius:"50%",background:STATUS_CONFIG[pendSt].dot,display:"inline-block"}}/>
                <span style={{fontSize:12,fontWeight:700,color:STATUS_CONFIG[pendSt].color}}>{STATUS_CONFIG[pendSt].label}{pendSt===STATUS.DOWN&&pendDur?<span style={{fontWeight:400,color:"#94a3b8"}}> · {DOWN_OPTS.find(o=>o.ms===pendDur)?.label}</span>:""}</span>
              </div>
              <input placeholder='Optional — e.g. "Sign says back Monday"' value={noteText} onChange={e=>setNoteText(e.target.value)} style={{...iS,marginBottom:16}}/>
              <button onClick={async()=>{const data={status:pendSt,lastReport:Date.now(),reportCount:(selected.reportCount||0)+1,downDuration:pendSt===STATUS.DOWN?pendDur:null,note:noteText.trim()};await saveStoreData(selected.id,data);setStep("status");setPendSt(null);setPendDur(null);setNoteText("");showToast("Report submitted! Thank you 🙏");setView("home");}} style={{width:"100%",padding:14,background:"linear-gradient(135deg,#22c55e,#16a34a)",border:"none",borderRadius:12,color:"#fff",fontWeight:800,fontSize:15,cursor:"pointer",fontFamily:"system-ui",boxShadow:"0 4px 16px rgba(34,197,94,0.3)"}}>Submit Report</button>
              <button onClick={()=>setStep(pendSt===STATUS.DOWN?"dur":"status")} style={{display:"block",margin:"12px auto 0",fontSize:12,color:"#94a3b8",background:"none",border:"none",cursor:"pointer",fontFamily:"system-ui"}}>← Back</button>
            </>)}
          </div>
        </div>
        {toast&&<Toast msg={toast}/>}
      </div>
    );
  }

  // ── HOME VIEW ──
  return(
    <div style={{minHeight:"100vh",background:"#f1f5f9",fontFamily:"system-ui",color:"#0f172a"}}>
      {/* Header */}
      <div style={{background:"linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%)",padding:"clamp(20px,4vw,32px) 20px 24px",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:-80,right:-80,width:220,height:220,borderRadius:"50%",background:"rgba(255,255,255,0.03)",pointerEvents:"none"}}/>
        <div style={{position:"absolute",bottom:-60,left:-60,width:200,height:200,borderRadius:"50%",background:"rgba(255,255,255,0.02)",pointerEvents:"none"}}/>
        <div style={{maxWidth:640,margin:"0 auto",position:"relative"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:12}}>
            <div>
              <div style={{display:"inline-flex",alignItems:"center",gap:6,background:"rgba(239,68,68,0.15)",border:"1px solid rgba(239,68,68,0.3)",borderRadius:20,padding:"3px 12px",marginBottom:10}}>
                <span style={{width:5,height:5,borderRadius:"50%",background:"#ef4444",display:"inline-block"}}/>
                <span style={{fontSize:9,letterSpacing:4,color:"#fca5a5",fontWeight:700}}>LIVE · CROWDSOURCED</span>
              </div>
              <h1 style={{margin:"0 0 4px",fontSize:"clamp(20px,5vw,30px)",fontWeight:900,color:"#fff",letterSpacing:-0.5,lineHeight:1.1}}>Staples Return<br/>Status</h1>
              <p style={{margin:0,fontSize:12,color:"rgba(255,255,255,0.4)"}}>Amazon QR kiosk · Community powered</p>
            </div>
            <div style={{display:"flex",gap:8,flexShrink:0}}>
              <div style={{background:"rgba(34,197,94,0.12)",border:"1px solid rgba(34,197,94,0.25)",borderRadius:12,padding:"8px 14px",textAlign:"center"}}>
                <div style={{fontSize:22,fontWeight:900,color:"#22c55e",lineHeight:1}}>{upCount}</div>
                <div style={{fontSize:9,color:"rgba(34,197,94,0.7)",letterSpacing:1,marginTop:2}}>UP</div>
              </div>
              <div style={{background:"rgba(239,68,68,0.12)",border:"1px solid rgba(239,68,68,0.25)",borderRadius:12,padding:"8px 14px",textAlign:"center"}}>
                <div style={{fontSize:22,fontWeight:900,color:"#ef4444",lineHeight:1}}>{downCount}</div>
                <div style={{fontSize:9,color:"rgba(239,68,68,0.7)",letterSpacing:1,marginTop:2}}>DOWN</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div style={{background:"#fff",borderBottom:"1px solid #e2e8f0",padding:"12px 16px",position:"sticky",top:0,zIndex:10}}>
        <div style={{maxWidth:640,margin:"0 auto"}}>
          <input placeholder="🔍  Search city, state, address..."
            value={searchText} onChange={e=>setSearchText(e.target.value)}
            style={{...iS,marginBottom:8}}/>
          <div style={{display:"flex",gap:8}}>
            <input placeholder="ZIP code (e.g. 10001)"
              value={zipInput} onChange={e=>setZipInput(e.target.value.replace(/\D/g,"").slice(0,5))}
              onKeyDown={e=>e.key==="Enter"&&handleZip()}
              style={{...iS,flex:1}}/>
            <button onClick={handleZip} style={{padding:"11px 20px",background:"#0f172a",border:"none",borderRadius:10,color:"#fff",fontSize:13,cursor:"pointer",fontFamily:"system-ui",fontWeight:700,whiteSpace:"nowrap"}}>Search</button>
            <button onClick={handleGeo} style={{padding:"11px 14px",background:refLoc?.label==="Your location"?"#f0fdf4":"#f8fafc",border:`1.5px solid ${refLoc?.label==="Your location"?"#bbf7d0":"#e2e8f0"}`,borderRadius:10,fontSize:18,cursor:"pointer",color:refLoc?.label==="Your location"?"#16a34a":"#94a3b8"}}>{geoLoading?"⏳":"📍"}</button>
          </div>
          {refLoc&&<div style={{fontSize:11,color:"#16a34a",marginTop:6,fontWeight:600}}>📍 {refLoc.label}</div>}
        </div>
      </div>

      <div style={{maxWidth:640,margin:"0 auto",padding:"16px 16px 100px"}}>
        {/* Ad */}
        {activeAd&&<div onClick={()=>activeAd.url&&window.open(activeAd.url,"_blank")} style={{background:"linear-gradient(135deg,#0f172a,#1e3a5f)",borderRadius:14,padding:"14px 16px",marginBottom:16,display:"flex",alignItems:"center",gap:12,cursor:activeAd.url?"pointer":"default",border:"1px solid rgba(255,255,255,0.06)"}}>
          <div style={{fontSize:9,color:"rgba(255,255,255,0.3)",letterSpacing:3,border:"1px solid rgba(255,255,255,0.1)",padding:"2px 6px",borderRadius:4,flexShrink:0}}>AD</div>
          <div style={{flex:1}}><div style={{fontSize:13,color:"#fff",fontWeight:700}}>{activeAd.headline}</div>{activeAd.subtext&&<div style={{fontSize:11,color:"rgba(255,255,255,0.45)",marginTop:1}}>{activeAd.subtext}</div>}</div>
          {activeAd.cta&&<div style={{fontSize:11,color:"#38bdf8",border:"1px solid rgba(56,189,248,0.3)",borderRadius:6,padding:"5px 12px",flexShrink:0,fontWeight:600}}>{activeAd.cta}</div>}
        </div>}

        {loading&&<div style={{textAlign:"center",padding:60,color:"#94a3b8"}}><div style={{fontSize:32,marginBottom:8}}>📦</div><div style={{fontSize:12,letterSpacing:3,fontWeight:600}}>LOADING...</div></div>}

        {/* Store cards */}
        {displayed.map(store=>{
          const st=effSt(store);const cfg=STATUS_CONFIG[st];
          const resetMs=store.status===STATUS.DOWN?store.downDuration:RESET_MS[store.status];
          const remaining=left(store.lastReport,resetMs);
          const d=store._d;
          return(
            <button key={store.id} onClick={()=>{setSelectedId(store.id);setView("detail");setStep("status");setPendSt(null);setPendDur(null);setNoteText("");}}
              style={{width:"100%",display:"block",background:"#fff",border:`1.5px solid ${st!==STATUS.UNKNOWN?cfg.border:"#e2e8f0"}`,borderRadius:16,marginBottom:10,padding:0,cursor:"pointer",textAlign:"left",fontFamily:"system-ui",boxShadow:st!==STATUS.UNKNOWN?`0 2px 12px ${cfg.dot}22`:"0 1px 4px rgba(0,0,0,0.04)",overflow:"hidden"}}>
              <div style={{height:3,background:cfg.dot,opacity:st!==STATUS.UNKNOWN?1:0}}/>
              <div style={{padding:"14px 16px",display:"flex",alignItems:"center",gap:12}}>
                <div style={{width:44,height:44,borderRadius:12,background:cfg.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>
                  {st===STATUS.UP?"✅":st===STATUS.DOWN?"🔴":st===STATUS.BUSY?"🟡":"📦"}
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontWeight:700,fontSize:14,marginBottom:2}}>{store.address}</div>
                  <div style={{fontSize:12,color:"#94a3b8"}}>{store.city}, {store.state} {store.zip}</div>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginTop:6,flexWrap:"wrap"}}>
                    <span style={{fontSize:11,fontWeight:700,color:cfg.color,background:cfg.bg,border:`1px solid ${cfg.border}`,borderRadius:20,padding:"2px 10px"}}>{cfg.label}</span>
                    {store.lastReport&&st!==STATUS.UNKNOWN&&<span style={{fontSize:11,color:"#cbd5e1"}}>{ago(store.lastReport)}</span>}
                    {remaining&&<span style={{fontSize:11,color:cfg.color,opacity:0.7}}>{remaining} left</span>}
                  </div>
                  {store.note&&st!==STATUS.UNKNOWN&&<div style={{fontSize:11,color:"#94a3b8",marginTop:4,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>"{store.note}"</div>}
                </div>
                <div style={{textAlign:"right",flexShrink:0}}>
                  {d!==undefined&&d<9999&&<div style={{fontSize:11,fontWeight:600,color:"#94a3b8",marginBottom:4}}>{d<0.1?"<0.1":d.toFixed(1)} mi</div>}
                  <span style={{fontSize:20,color:"#cbd5e1"}}>›</span>
                </div>
              </div>
            </button>
          );
        })}
        {!loading&&displayed.length===0&&<div style={{textAlign:"center",padding:60}}><div style={{fontSize:40,marginBottom:12}}>🔍</div><div style={{fontSize:16,fontWeight:700,marginBottom:6}}>No stores found</div><div style={{fontSize:13,color:"#94a3b8"}}>Try a different ZIP or search term</div></div>}
        <div style={{textAlign:"center",fontSize:10,color:"#cbd5e1",letterSpacing:1,marginTop:24,lineHeight:2}}>ALL STAPLES LOCATIONS ACCEPT AMAZON RETURNS<br/><span onClick={()=>setView("adminLogin")} style={{cursor:"default",opacity:0.3}}>⚙</span></div>
      </div>
      {toast&&<Toast msg={toast}/>}
      <style>{`* { -webkit-tap-highlight-color: transparent; } button:focus { outline: none; } input:focus { border-color: #94a3b8 !important; }`}</style>
    </div>
  );
}
