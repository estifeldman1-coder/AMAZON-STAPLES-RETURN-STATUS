import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Polyfill window.storage using localStorage so the app works deployed
// (In Claude preview it uses the built-in storage API)
if (!window.storage) {
  window.storage = {
    get: async (key, shared) => {
      try {
        const prefix = shared ? 'shared_' : 'local_';
        const val = localStorage.getItem(prefix + key);
        if (val === null) throw new Error('Not found');
        return { key, value: val, shared: !!shared };
      } catch {
        throw new Error('Not found');
      }
    },
    set: async (key, value, shared) => {
      const prefix = shared ? 'shared_' : 'local_';
      localStorage.setItem(prefix + key, value);
      return { key, value, shared: !!shared };
    },
    delete: async (key, shared) => {
      const prefix = shared ? 'shared_' : 'local_';
      localStorage.removeItem(prefix + key);
      return { key, deleted: true, shared: !!shared };
    },
    list: async (prefix, shared) => {
      const storagePrefix = (shared ? 'shared_' : 'local_') + (prefix || '');
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(storagePrefix)) {
          keys.push(k.replace(shared ? 'shared_' : 'local_', ''));
        }
      }
      return { keys, prefix, shared: !!shared };
    }
  };
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
