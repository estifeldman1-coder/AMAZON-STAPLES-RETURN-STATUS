# Staples Return Status App

Real-time crowdsourced Amazon QR kiosk status for Staples locations.

---

## Deploy to Vercel (Free) — Step by Step

### 1. Upload to GitHub
1. Go to github.com and sign in
2. Click the **+** button (top right) → **New repository**
3. Name it `staples-return-status`
4. Click **Create repository**
5. On the next page, click **uploading an existing file**
6. Drag and drop ALL files from this folder into the upload area
7. Click **Commit changes**

### 2. Deploy on Vercel
1. Go to vercel.com and sign in with GitHub
2. Click **Add New → Project**
3. Find your `staples-return-status` repo and click **Import**
4. Leave all settings as default — Vercel auto-detects React
5. Click **Deploy**
6. Wait ~2 minutes — your app is live! 🎉

You'll get a free URL like: `https://staples-return-status.vercel.app`

---

## Install as App on iPhone
1. Open your Vercel URL in Safari
2. Tap the Share button (square with arrow)
3. Tap **Add to Home Screen**
4. Tap **Add**
5. It now appears on your home screen like a real app!

## Install as App on Android
1. Open your Vercel URL in Chrome
2. Tap the 3-dot menu
3. Tap **Add to Home Screen**
4. Done!

---

## Admin Panel
- Tap the tiny ⚙ at the bottom of the home screen
- Password: `staples2024`
- Change the password in `src/App.jsx` line 4 before deploying

---

## Notes
- All reports are stored in the user's browser (localStorage)
- To make reports shared across ALL users, you'll need a backend (Firebase free tier works great)
- The ZIP database covers all major US metro areas
